# Backend

Generated stub for cooler-asset-manager. Run with `node server/index.js` after wiring an Express server.
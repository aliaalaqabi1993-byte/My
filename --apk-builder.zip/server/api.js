// server/api.js
// Express-style handlers مع mock data في الذاكرة
// نظام إدارة البرادات والعقود والصيانة

const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');

// ============================================================================
// MOCK DATA - في الذاكرة فقط
// ============================================================================

const mockData = {
  users: [
    {
      id: 'user-1',
      email: 'admin@cooler.com',
      password: '$2b$10$hashedPassword123', // مشفرة
      fullName: 'أحمد المسؤول',
      role: 'ADMIN',
      phone: '+966501234567',
      active: true,
      createdAt: new Date('2024-01-01'),
      updatedAt: new Date('2024-01-01'),
    },
    {
      id: 'user-2',
      email: 'delegate@cooler.com',
      password: '$2b$10$hashedPassword456',
      fullName: 'محمد الموكل',
      role: 'DELEGATE',
      phone: '+966502234567',
      active: true,
      createdAt: new Date('2024-01-05'),
      updatedAt: new Date('2024-01-05'),
    },
    {
      id: 'user-3',
      email: 'technician@cooler.com',
      password: '$2b$10$hashedPassword789',
      fullName: 'علي الفني',
      role: 'TECHNICIAN',
      phone: '+966503234567',
      active: true,
      createdAt: new Date('2024-01-10'),
      updatedAt: new Date('2024-01-10'),
    },
  ],
  coolers: [
    {
      id: 'cooler-1',
      serialNumber: 'SN-2024-001',
      latitude: 24.7136,
      longitude: 46.6753,
      locationName: 'الرياض - مول العرب',
      status: 'ACTIVE',
      model: 'CoolBox Pro 500',
      purchaseDate: new Date('2023-06-15'),
      lastMaintenanceDate: new Date('2024-02-20'),
      createdAt: new Date('2023-06-15'),
      updatedAt: new Date('2024-02-20'),
    },
    {
      id: 'cooler-2',
      serialNumber: 'SN-2024-002',
      latitude: 24.7585,
      longitude: 46.7406,
      locationName: 'الرياض - فندق الملك',
      status: 'ACTIVE',
      model: 'CoolBox Pro 500',
      purchaseDate: new Date('2023-07-10'),
      lastMaintenanceDate: new Date('2024-02-10'),
      createdAt: new Date('2023-07-10'),
      updatedAt: new Date('2024-02-10'),
    },
    {
      id: 'cooler-3',
      serialNumber: 'SN-2024-003',
      latitude: 24.6639,
      longitude: 46.7099,
      locationName: 'الرياض - مستشفى الملك فهد',
      status: 'MAINTENANCE',
      model: 'CoolBox Standard 300',
      purchaseDate: new Date('2023-08-20'),
      lastMaintenanceDate: new Date('2024-03-01'),
      createdAt: new Date('2023-08-20'),
      updatedAt: new Date('2024-03-01'),
    },
  ],
  contracts: [
    {
      id: 'contract-1',
      coolerId: 'cooler-1',
      customerId: 'cust-1',
      customerName: 'أحمد السلمان',
      customerPhone: '+966501111111',
      customerAddress: 'الرياض - شارع التخصصي',
      contractDate: new Date('2024-01-15'),
      expiryDate: new Date('2025-01-15'),
      status: 'ACTIVE',
      createdBy: 'user-2',
      customerPhotoUrl: 'https://example.com/photos/cust-1.jpg',
      coolerPhotoUrl: 'https://example.com/photos/cooler-1.jpg',
      createdAt: new Date('2024-01-15'),
      updatedAt: new Date('2024-01-15'),
    },
    {
      id: 'contract-2',
      coolerId: 'cooler-2',
      customerId: 'cust-2',
      customerName: 'فاطمة محمد',
      customerPhone: '+966502222222',
      customerAddress: 'الرياض - حي النخيل',
      contractDate: new Date('2024-02-01'),
      expiryDate: new Date('2025-02-01'),
      status: 'ACTIVE',
      createdBy: 'user-2',
      customerPhotoUrl: 'https://example.com/photos/cust-2.jpg',
      coolerPhotoUrl: 'https://example.com/photos/cooler-2.jpg',
      createdAt: new Date('2024-02-01'),
      updatedAt: new Date('2024-02-01'),
    },
  ],
  maintenanceTickets: [
    {
      id: 'ticket-1',
      coolerId: 'cooler-1',
      title: 'فحص دوري شامل',
      description: 'فحص الضاغط والمراوح والتبريد',
      status: 'RESOLVED',
      priority: 'MEDIUM',
      assignedTo: 'user-3',
      reportedBy: 'user-2',
      openedDate: new Date('2024-02-15T08:00:00Z'),
      resolvedDate: new Date('2024-02-20T14:30:00Z'),
      notes: 'تم استبدال الفلتر وتنظيف المكثف',
      createdAt: new Date('2024-02-15'),
      updatedAt: new Date('2024-02-20'),
    },
    {
      id: 'ticket-2',
      coolerId: 'cooler-3',
      title: 'عطل في نظام التبريد',
      description: 'درجة الحرارة لا تنخفض كما هو متوقع',
      status: 'IN_PROGRESS',
      priority: 'HIGH',
      assignedTo: 'user-3',
      reportedBy: 'user-2',
      openedDate: new Date('2024-03-01T10:00:00Z'),
      resolvedDate: null,
      notes: 'يتم فحص الضاغط حالياً',
      createdAt: new Date('2024-03-01'),
      updatedAt: new Date('2024-03-05'),
    },
  ],
  sessions: {}, // لتخزين JWT tokens
};

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

/**
 * التحقق من صحة JWT token (محاكاة)
 */
const verifyToken = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) {
    return res.status(401).json({ error: 'لا يوجد توكن' });
  }
  // في الواقع ستتحقق من التوقيع باستخدام jwt.verify()
  const userId = mockData.sessions[token];
  if (!userId) {
    return res.status(401).json({ error: 'توكن غير صالح' });
  }
  req.userId = userId;
  const user = mockData.users.find((u) => u.id === userId);
  req.user = user;
  next();
};

/**
 * التحقق من الدور (role-based access control)
 */
const checkRole = (allowedRoles) => {
  return (req, res, next) => {
    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({ error: 'غير مصرح بهذه العملية' });
    }
    next();
  };
};

/**
 * توليد رقم UUID
 */
const generateId = () => uuidv4();

/**
 * البحث والفلترة
 */
const applyFilters = (items, filters) => {
  let result = items;
  if (filters.search) {
    result = result.filter(
      (item) =>
        item.name?.toLowerCase().includes(filters.search.toLowerCase()) ||
        item.serialNumber?.toLowerCase().includes(filters.search.toLowerCase()) ||
        item.customerName?.toLowerCase().includes(filters.search.toLowerCase())
    );
  }
  if (filters.status) {
    result = result.filter((item) => item.status === filters.status);
  }
  if (filters.role) {
    result = result.filter((item) => item.role === filters.role);
  }
  if (filters.priority) {
    result = result.filter((item) => item.priority === filters.priority);
  }
  return result;
};

// ============================================================================
// AUTH ENDPOINTS
// ============================================================================

/**
 * POST /api/auth/login
 * تسجيل دخول المستخدم
 */
router.post('/auth/login', (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'البريد الإلكتروني وكلمة المرور مطلوبة' });
  }

  const user = mockData.users.find((u) => u.email === email);
  if (!user || user.password !== password) {
    return res.status(401).json({ error: 'بيانات الدخول غير صحيحة' });
  }

  if (!user.active) {
    return res.status(403).json({ error: 'حساب المستخدم غير نشط' });
  }

  // توليد JWT token (محاكاة)
  const token = `jwt_${generateId()}`;
  mockData.sessions[token] = user.id;

  res.json({
    success: true,
    message: 'تم تسجيل الدخول بنجاح',
    token,
    user: {
      id: user.id,
      email: user.email,
      fullName: user.fullName,
      role: user.role,
      phone: user.phone,
    },
  });
});

/**
 * POST /api/auth/logout
 * تسجيل خروج المستخدم
 */
router.post('/auth/logout', verifyToken, (req, res) => {
  const token = req.headers.authorization?.split(' ')[1];
  delete mockData.sessions[token];

  res.json({
    success: true,
    message: 'تم تسجيل الخروج بنجاح',
  });
});

/**
 * GET /api/auth/me
 * الحصول على بيانات المستخدم الحالي
 */
router.get('/auth/me', verifyToken, (req, res) => {
  res.json({
    success: true,
    user: {
      id: req.user.id,
      email: req.user.email,
      fullName: req.user.fullName,
      role: req.user.role,
      phone: req.user.phone,
      active: req.user.active,
      createdAt: req.user.createdAt,
    },
  });
});

// ============================================================================
// DASHBOARD ENDPOINTS
// ============================================================================

/**
 * GET /api/dashboard/statistics
 * إحصائيات عامة
 */
router.get('/dashboard/statistics', verifyToken, (req, res) => {
  const totalCoolers = mockData.coolers.length;
  const activeCoolers = mockData.coolers.filter((c) => c.status === 'ACTIVE').length;
  const maintenanceCoolers = mockData.coolers.filter((c) => c.status === 'MAINTENANCE').length;
  const totalContracts = mockData.contracts.length;
  const activeContracts = mockData.contracts.filter((c) => c.status === 'ACTIVE').length;
  const openTickets = mockData.maintenanceTickets.filter((t) => t.status === 'OPEN' || t.status === 'IN_PROGRESS').length;
  const criticalTickets = mockData.maintenanceTickets.filter((t) => t.priority === 'CRITICAL').length;

  res.json({
    success: true,
    statistics: {
      coolers: {
        total: totalCoolers,
        active: activeCoolers,
        maintenance: maintenanceCoolers,
        inactive: totalCoolers - activeCoolers - maintenanceCoolers,
      },
      contracts: {
        total: totalContracts,
        active: activeContracts,
        expired: totalContracts - activeContracts,
      },
      maintenance: {
        openTickets,
        criticalTickets,
        totalTickets: mockData.maintenanceTickets.length,
      },
      users: {
        total: mockData.users.length,
        admins: mockData.users.filter((u) => u.role === 'ADMIN').length,
        delegates: mockData.users.filter((u) => u.role === 'DELEGATE').length,
        technicians: mockData.users.filter((u) => u.role === 'TECHNICIAN').length,
      },
    },
  });
});

// ============================================================================
// COOLERS ENDPOINTS
// ============================================================================

/**
 * GET /api/coolers
 * الحصول على قائمة البرادات مع الفلترة والبحث
 */
router.get('/coolers', verifyToken, (req, res) => {
  const { search, status, page = 1, limit = 10 } = req.query;
  let coolers = mockData.coolers;

  // تطبيق الفلاتر
  coolers = applyFilters(coolers, { search, status });

  // التصفح
  const startIndex = (page - 1) * limit;
  const paginatedCoolers = coolers.slice(startIndex, startIndex + parseInt(limit));

  res.json({
    success: true,
    data: paginatedCoolers,
    pagination: {
      total: coolers.length,
      page: parseInt(page),
      limit: parseInt(limit),
      pages: Math.ceil(coolers.length / limit),
    },
  });
});

/**
 * GET /api/coolers/:id
 * الحصول على براد واحد
 */
router.get('/coolers/:id', verifyToken, (req, res) => {
  const cooler = mockData.coolers.find((c) => c.id === req.params.id);
  if (!cooler) {
    return res.status(404).json({ error: 'البراد غير موجود' });
  }

  res.json({
    success: true,
    data: cooler,
  });
});

/**
 * POST /api/coolers
 * إضافة براد جديد
 */
router.post('/coolers', verifyToken, checkRole(['ADMIN', 'DELEGATE']), (req, res) => {
  const { serialNumber, latitude, longitude, locationName, model, purchaseDate } = req.body;

  if (!serialNumber || latitude === undefined || longitude === undefined || !locationName) {
    return res.status(400).json({ error: 'البيانات المطلوبة غير كاملة' });
  }

  // التحقق من عدم تكرار الرقم التسلسلي
  if (mockData.coolers.some((c) => c.serialNumber === serialNumber)) {
    return res.status(409).json({ error: 'الرقم التسلسلي موجود بالفعل' });
  }

  const newCooler = {
    id: generateId(),
    serialNumber,
    latitude: parseFloat(latitude),
    longitude: parseFloat(longitude),
    locationName,
    status: 'ACTIVE',
    model: model || 'Unknown',
    purchaseDate: new Date(purchaseDate),
    lastMaintenanceDate: null,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  mockData.coolers.push(newCooler);

  res.status(201).json({
    success: true,
    message: 'تم إضافة البراد بنجاح',
    data: newCooler,
  });
});

/**
 * PUT /api/coolers/:id
 * تعديل براد
 */
router.put('/coolers/:id', verifyToken, checkRole(['ADMIN', 'DELEGATE']), (req, res) => {
  const cooler = mockData.coolers.find((c) => c.id === req.params.id);
  if (!cooler) {
    return res.status(404).json({ error: 'البراد غير موجود' });
  }

  const { latitude, longitude, locationName, status, model } = req.body;

  if (latitude !== undefined) cooler.latitude = parseFloat(latitude);
  if (longitude !== undefined) cooler.longitude = parseFloat(longitude);
  if (locationName) cooler.locationName = locationName;
  if (status && ['ACTIVE', 'INACTIVE', 'MAINTENANCE', 'DAMAGED'].includes(status)) {
    cooler.status = status;
  }
  if (model) cooler.model = model;
  cooler.updatedAt = new Date();

  res.json({
    success: true,
    message: 'تم تحديث البراد بنجاح',
    data: cooler,
  });
});

/**
 * DELETE /api/coolers/:id
 * حذف براد
 */
router.delete('/coolers/:id', verifyToken, checkRole(['ADMIN']), (req, res) => {
  const index = mockData.coolers.findIndex((c) => c.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: 'البراد غير موجود' });
  }

  const deleted = mockData.coolers.splice(index, 1);

  res.json({
    success: true,
    message: 'تم حذف البراد بنجاح',
    data: deleted[0],
  });
});

/**
 * GET /api/coolers/map/locations
 * مواقع البرادات للخريطة
 */
router.get('/coolers/map/locations', verifyToken, (req, res) => {
  const locations = mockData.coolers.map((cooler) => ({
    id: cooler.id,
    serialNumber: cooler.serialNumber,
    latitude: cooler.latitude,
    longitude: cooler.longitude,
    locationName: cooler.locationName,
    status: cooler.status,
  }));

  res.json({
    success: true,
    data: locations,
  });
});

/**
 * GET /api/coolers/barcode/:barcode
 * البحث عن براد بالباركود
 */
router.get('/coolers/barcode/:barcode', verifyToken, (req, res) => {
  const cooler = mockData.coolers.find((c) => c.serialNumber === req.params.barcode);
  if (!cooler) {
    return res.status(404).json({ error: 'البراد غير موجود' });
  }

  res.json({
    success: true,
    data: cooler,
  });
});

// ============================================================================
// CONTRACTS ENDPOINTS
// ============================================================================

/**
 * GET /api/contracts
 * الحصول على جميع العقود
 */
router.get('/contracts', verifyToken, (req, res) => {
  const { status, search, page = 1, limit = 10 } = req.query;
  let contracts = mockData.contracts;

  contracts = applyFilters(contracts, { status, search });

  const startIndex = (page - 1) * limit;
  const paginatedContracts = contracts.slice(startIndex, startIndex + parseInt(limit));

  res.json({
    success: true,
    data: paginatedContracts,
    pagination: {
      total: contracts.length,
      page: parseInt(page),
      limit: parseInt(limit),
      pages: Math.ceil(contracts.length / limit),
    },
  });
});

/**
 * GET /api/contracts/:id
 * الحصول على عقد واحد
 */
router.get('/contracts/:id', verifyToken, (req, res) => {
  const contract = mockData.contracts.find((c) => c.id === req.params.id);
  if (!contract) {
    return res.status(404).json({ error: 'العقد غير موجود' });
  }

  // إرجاع بيانات العقد مع تفاصيل البراد والعميل
  const cooler = mockData.coolers.find((c) => c.id === contract.coolerId);
  const creator = mockData.users.find((u) => u.id === contract.createdBy);

  res.json({
    success: true,
    data: {
      ...contract,
      cooler,
      creator: creator ? { id: creator.id, fullName: creator.fullName, email: creator.email } : null,
    },
  });
});

/**
 * POST /api/contracts
 * إضافة عقد جديد
 */
router.post('/contracts', verifyToken, checkRole(['ADMIN', 'DELEGATE']), (req, res) => {
  const { coolerId, customerId, customerName, customerPhone, customerAddress, expiryDate, customerPhotoUrl, coolerPhotoUrl } = req.body;

  if (!coolerId || !customerId || !customerName) {
    return res.status(400).json({ error: 'البيانات المطلوبة غير كاملة' });
  }

  const cooler = mockData.coolers.find((c) => c.id === coolerId);
  if (!cooler) {
    return res.status(404).json({ error: 'البراد غير موجود' });
  }

  const newContract = {
    id: generateId(),
    coolerId,
    customerId,
    customerName,
    customerPhone: customerPhone || '',
    customerAddress: customerAddress || '',
    contractDate: new Date(),
    expiryDate: new Date(expiryDate),
    status: 'ACTIVE',
    createdBy: req.userId,
    customerPhotoUrl: customerPhotoUrl || '',
    coolerPhotoUrl: coolerPhotoUrl || '',
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  mockData.contracts.push(newContract);

  res.status(201).json({
    success: true,
    message: 'تم إضافة العقد بنجاح',
    data: newContract,
  });
});

/**
 * PUT /api/contracts/:id
 * تعديل عقد
 */
router.put('/contracts/:id', verifyToken, checkRole(['ADMIN', 'DELEGATE']), (req, res) => {
  const contract = mockData.contracts.find((c) => c.id === req.params.id);
  if (!contract) {
    return res.status(404).json({ error: 'العقد غير موجود' });
  }

  const { customerName, customerPhone, customerAddress, expiryDate, status } = req.body;

  if (customerName) contract.customerName = customerName;
  if (customerPhone) contract.customerPhone = customerPhone;
  if (customerAddress) contract.customerAddress = customerAddress;
  if (expiryDate) contract.expiryDate = new Date(expiryDate);
  if (status && ['ACTIVE', 'EXPIRED', 'TERMINATED'].includes(status)) {
    contract.status = status;
  }
  contract.updatedAt = new Date();

  res.json({
    success: true,
    message: 'تم تحديث العقد بنجاح',
    data: contract,
  });
});

/**
 * DELETE /api/contracts/:id
 * حذف عقد
 */
router.delete('/contracts/:id', verifyToken, checkRole(['ADMIN']), (req, res) => {
  const index = mockData.contracts.findIndex((c) => c.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: 'العقد غير موجود' });
  }

  const deleted = mockData.contracts.splice(index, 1);

  res.json({
    success: true,
    message: 'تم حذف العقد بنجاح',
    data: deleted[0],
  });
});

// ============================================================================
// USERS ENDPOINTS
// ============================================================================

/**
 * GET /api/users
 * الحصول على جميع المستخدمين
 */
router.get('/users', verifyToken, checkRole(['ADMIN']), (req, res) => {
  const { role, search, page = 1, limit = 10 } = req.query;
  let users = mockData.users;

  users = applyFilters(users, { role, search });

  const startIndex = (page - 1) * limit;
  const paginatedUsers = users.slice(startIndex, startIndex + parseInt(limit));

  const sanitized = paginatedUsers.map((u) => ({
    id: u.id,
    email: u.email,
    fullName: u.fullName,
    role: u.role,
    phone: u.phone,
    active: u.active,
    createdAt: u.createdAt,
  }));

  res.json({
    success: true,
    data: sanitized,
    pagination: {
      total: users.length,
      page: parseInt(page),
      limit: parseInt(limit),
      pages: Math.ceil(users.length / limit),
    },
  });
});

/**
 * GET /api/users/:id
 * الحصول على مستخدم واحد
 */
router.get('/users/:id', verifyToken, checkRole(['ADMIN']), (req, res) => {
  const user = mockData.users.find((u) => u.id === req.params.id);
  if (!user) {
    return res.status(404).json({ error: 'المستخدم غير موجود' });
  }

  res.json({
    success: true,
    data: {
      id: user.id,
      email: user.email,
      fullName: user.fullName,
      role: user.role,
      phone: user.phone,
      active: user.active,
      createdAt: user.createdAt,
    },
  });
});

/**
 * POST /api/users
 * إضافة مستخدم جديد
 */
router.post('/users', verifyToken, checkRole(['ADMIN']), (req, res) => {
  const { email, password, fullName, role, phone } = req.body;

  if (!email || !password || !fullName || !role) {
    return res.status(400).json({ error: 'البيانات المطلوبة غير كاملة' });
  }

  if (mockData.users.some((u) => u.email === email)) {
    return res.status(409).json({ error: 'البريد الإلكتروني موجود بالفعل' });
  }

  if (!['ADMIN', 'DELEGATE', 'TECHNICIAN'].includes(role)) {
    return res.status(400).json({ error: 'الدور غير صحيح' });
  }

  const newUser = {
    id: generateId(),
    email,
    password: `$2b$10$hashed${generateId()}`, // في الواقع تشفير bcrypt
    fullName,
    role,
    phone: phone || '',
    active: true,
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  mockData.users.push(newUser);

  res.status(201).json({
    success: true,
    message: 'تم إضافة المستخدم بنجاح',
    data: {
      id: newUser.id,
      email: newUser.email,
      fullName: newUser.fullName,
      role: newUser.role,
      phone: newUser.phone,
      active: newUser.active,
    },
  });
});

/**
 * PUT /api/users/:id
 * تعديل مستخدم
 */
router.put('/users/:id', verifyToken, checkRole(['ADMIN']), (req, res) => {
  const user = mockData.users.find((u) => u.id === req.params.id);
  if (!user) {
    return res.status(404).json({ error: 'المستخدم غير موجود' });
  }

  const { fullName, role, phone, active } = req.body;

  if (fullName) user.fullName = fullName;
  if (role && ['ADMIN', 'DELEGATE', 'TECHNICIAN'].includes(role)) {
    user.role = role;
  }
  if (phone) user.phone = phone;
  if (active !== undefined) user.active = active;
  user.updatedAt = new Date();

  res.json({
    success: true,
    message: 'تم تحديث المستخدم بنجاح',
    data: {
      id: user.id,
      email: user.email,
      fullName: user.fullName,
      role: user.role,
      phone: user.phone,
      active: user.active,
    },
  });
});

/**
 * DELETE /api/users/:id
 * حذف مستخدم
 */
router.delete('/users/:id', verifyToken, checkRole(['ADMIN']), (req, res) => {
  const index = mockData.users.findIndex((u) => u.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: 'المستخدم غير موجود' });
  }

  // منع حذف المستخدم الحالي
  if (req.userId === req.params.id) {
    return res.status(400).json({ error: 'لا يمكن حذف حسابك الخاص' });
  }

  const deleted = mockData.users.splice(index, 1);

  res.json({
    success: true,
    message: 'تم حذف المستخدم بنجاح',
    data: {
      id: deleted[0].id,
      email: deleted[0].email,
      fullName: deleted[0].fullName,
    },
  });
});

// ============================================================================
// MAINTENANCE TICKETS ENDPOINTS
// ============================================================================

/**
 * GET /api/maintenance-tickets
 * الحصول على جميع التذاكر
 */
router.get('/maintenance-tickets', verifyToken, (req, res) => {
  const { status, priority, page = 1, limit = 10 } = req.query;
  let tickets = mockData.maintenanceTickets;

  tickets = applyFilters(tickets, { status, priority });

  const startIndex = (page - 1) * limit;
  const paginatedTickets = tickets.slice(startIndex, startIndex + parseInt(limit));

  res.json({
    success: true,
    data: paginatedTickets,
    pagination: {
      total: tickets.length,
      page: parseInt(page),
      limit: parseInt(limit),
      pages: Math.ceil(tickets.length / limit),
    },
  });
});

/**
 * GET /api/maintenance-tickets/technician/:technicianId
 * تذاكر الفني
 */
router.get('/maintenance-tickets/technician/:technicianId', verifyToken, (req, res) => {
  const tickets = mockData.maintenanceTickets.filter((t) => t.assignedTo === req.params.technicianId);

  const grouped = {
    open: tickets.filter((t) => t.status === 'OPEN'),
    inProgress: tickets.filter((t) => t.status === 'IN_PROGRESS'),
    resolved: tickets.filter((t) => t.status === 'RESOLVED'),
    closed: tickets.filter((t) => t.status === 'CLOSED'),
  };

  res.json({
    success: true,
    data: grouped,
  });
});

/**
 * GET /api/maintenance-tickets/:id
 * تذكرة واحدة
 */
router.get('/maintenance-tickets/:id', verifyToken, (req, res) => {
  const ticket = mockData.maintenanceTickets.find((t) => t.id === req.params.id);
  if (!ticket) {
    return res.status(404).json({ error: 'التذكرة غير موجودة' });
  }

  const cooler = mockData.coolers.find((c) => c.id === ticket.coolerId);
  const assignedUser = mockData.users.find((u) => u.id === ticket.assignedTo);
  const reporter = mockData.users.find((u) => u.id === ticket.reportedBy);

  res.json({
    success: true,
    data: {
      ...ticket,
      cooler,
      assignedTo: assignedUser ? { id: assignedUser.id, fullName: assignedUser.fullName } : null,
      reportedBy: reporter ? { id: reporter.id, fullName: reporter.fullName } : null,
    },
  });
});

/**
 * POST /api/maintenance-tickets
 * إنشاء تذكرة جديدة
 */
router.post('/maintenance-tickets', verifyToken, checkRole(['ADMIN', 'DELEGATE', 'TECHNICIAN']), (req, res) => {
  const { coolerId, title, description, priority, assignedTo } = req.body;

  if (!coolerId || !title || !description || !priority) {
    return res.status(400).json({ error: 'البيانات المطلوبة غير كاملة' });
  }

  const cooler = mockData.coolers.find((c) => c.id === coolerId);
  if (!cooler) {
    return res.status(404).json({ error: 'البراد غير موجود' });
  }

  if (assignedTo) {
    const technician = mockData.users.find((u) => u.id === assignedTo && u.role === 'TECHNICIAN');
    if (!technician) {
      return res.status(404).json({ error: 'الفني غير موجود' });
    }
  }

  const newTicket = {
    id: generateId(),
    coolerId,
    title,
    description,
    status: 'OPEN',
    priority: priority || 'MEDIUM',
    assignedTo: assignedTo || null,
    reportedBy: req.userId,
    openedDate: new Date(),
    resolvedDate: null,
    notes: '',
    createdAt: new Date(),
    updatedAt: new Date(),
  };

  mockData.maintenanceTickets.push(newTicket);

  res.status(201).json({
    success: true,
    message: 'تم إنشاء التذكرة بنجاح',
    data: newTicket,
  });
});

/**
 * PUT /api/maintenance-tickets/:id
 * تحديث التذكرة
 */
router.put('/maintenance-tickets/:id', verifyToken, (req, res) => {
  const ticket = mockData.maintenanceTickets.find((t) => t.id === req.params.id);
  if (!ticket) {
    return res.status(404).json({ error: 'التذكرة غير موجودة' });
  }

  const { status, priority, assignedTo, notes } = req.body;

  if (status && ['OPEN', 'IN_PROGRESS', 'RESOLVED', 'CLOSED'].includes(status)) {
    ticket.status = status;
  }
  if (priority && ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'].includes(priority)) {
    ticket.priority = priority;
  }
  if (assignedTo) {
    const technician = mockData.users.find((u) => u.id === assignedTo && u.role === 'TECHNICIAN');
    if (!technician) {
      return res.status(404).json({ error: 'الفني غير موجود' });
    }
    ticket.assignedTo = assignedTo;
  }
  if (notes !== undefined) ticket.notes = notes;
  ticket.updatedAt = new Date();

  res.json({
    success: true,
    message: 'تم تحديث التذكرة بنجاح',
    data: ticket,
  });
});

/**
 * PUT /api/maintenance-tickets/:id/resolve
 * وضع علامة على التذكرة كمصلحة
 */
router.put('/maintenance-tickets/:id/resolve', verifyToken, checkRole(['TECHNICIAN']), (req, res) => {
  const ticket = mockData.maintenanceTickets.find((t) => t.id === req.params.id);
  if (!ticket) {
    return res.status(404).json({ error: 'التذكرة غير موجودة' });
  }

  if (ticket.assignedTo !== req.userId) {
    return res.status(403).json({ error: 'هذه التذكرة غير مسندة لك' });
  }

  ticket.status = 'RESOLVED';
  ticket.resolvedDate = new Date();
  ticket.updatedAt = new Date();

  // تحديث تاريخ الصيانة الأخيرة للبراد
  const cooler = mockData.coolers.find((c) => c.id === ticket.coolerId);
  if (cooler) {
    cooler.lastMaintenanceDate = new Date();
    cooler.updatedAt = new Date();
  }

  res.json({
    success: true,
    message: 'تم وضع علامة على التذكرة كمصلحة',
    data: ticket,
  });
});

// ============================================================================
// FILE UPLOAD ENDPOINT
// ============================================================================

/**
 * POST /api/upload
 * تحميل الصور
 */
router.post('/upload', verifyToken, (req, res) => {
  // في الواقع ستستخدم multer للتعامل مع الملفات
  // هنا محاكاة فقط
  const { filename, fileType } = req.body;

  if (!filename || !fileType) {
    return res.status(400).json({ error: 'اسم الملف والنوع مطلوبان' });
  }

  const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg'];
  if (!allowedTypes.includes(fileType)) {
    return res.status(400).json({ error: 'نوع الملف غير مدعوم' });
  }

  const fileUrl = `https://example.com/uploads/${generateId()}_${filename}`;

  res.json({
    success: true,
    message: 'تم تحميل الملف بنجاح',
    fileUrl,
  });
});

// ============================================================================
// EXPORT
// ============================================================================

module.exports = router;
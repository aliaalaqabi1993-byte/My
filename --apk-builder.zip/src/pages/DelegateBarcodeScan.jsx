import React, { useState } from 'react';

export default function BarcodeScanPage() {
  const [scanned, setScanned] = useState(false);
  const [data, setData] = useState({
    code: '',
    name: '',
    price: '',
    quantity: '',
    status: '',
  });

  const handleScan = () => {
    // Simulate a scan result
    setData({
      code: 'BR123456789',
      name: 'براد متطور 5000',
      price: '120,000',
      quantity: '25',
      status: 'موجود',
    });
    setScanned(true);
  };

  return (
    <div
      className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 flex flex-col"
      dir="rtl"
    >
      {/* Header */}
      <header className="bg-[#1976D2] text-white py-4 px-6 shadow-md">
        <h1 className="text-2xl font-semibold">مُسح الباركود</h1>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-6">
        <div className="max-w-2xl mx-auto">
          {/* Scan Button */}
          <button
            onClick={handleScan}
            className="w-full bg-[#1976D2] hover:bg-[#1565C0] text-white py-3 px-6 rounded-lg font-semibold transition-colors mb-6"
          >
            {scanned ? 'مسح آخر' : 'بدء المسح'}
          </button>

          {/* Results */}
          {scanned && (
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-semibold text-gray-600 dark:text-gray-400">الكود</label>
                  <p className="text-lg font-bold">{data.code}</p>
                </div>
                <div>
                  <label className="text-sm font-semibold text-gray-600 dark:text-gray-400">الاسم</label>
                  <p className="text-lg font-bold">{data.name}</p>
                </div>
                <div>
                  <label className="text-sm font-semibold text-gray-600 dark:text-gray-400">السعر</label>
                  <p className="text-lg font-bold">{data.price}</p>
                </div>
                <div>
                  <label className="text-sm font-semibold text-gray-600 dark:text-gray-400">الكمية</label>
                  <p className="text-lg font-bold">{data.quantity}</p>
                </div>
                <div>
                  <label className="text-sm font-semibold text-gray-600 dark:text-gray-400">الحالة</label>
                  <p className="text-lg font-bold text-green-600">{data.status}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
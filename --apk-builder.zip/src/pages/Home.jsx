import React, { useState } from 'react';
import { Eye, EyeOff, AlertCircle, CheckCircle, LogIn, Shield, Users, Wrench } from 'lucide-react';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [selectedRole, setSelectedRole] = useState('admin');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const roles = [
    {
      id: 'admin',
      name: 'مدير',
      label: 'Admin',
      icon: Shield,
      description: 'إدارة النظام والمستخدمين',
      color: 'from-blue-600 to-blue-700',
      lightColor: 'bg-blue-50',
      textColor: 'text-blue-700'
    },
    {
      id: 'delegate',
      name: 'مندوب',
      label: 'Delegate',
      icon: Users,
      description: 'إدارة المبيعات والعملاء',
      color: 'from-emerald-600 to-emerald-700',
      lightColor: 'bg-emerald-50',
      textColor: 'text-emerald-700'
    },
    {
      id: 'technician',
      name: 'فني',
      label: 'Technician',
      icon: Wrench,
      description: 'الدعم الفني والصيانة',
      color: 'from-orange-600 to-orange-700',
      lightColor: 'bg-orange-50',
      textColor: 'text-orange-700'
    }
  ];

  const currentRole = roles.find(r => r.id === selectedRole);
  const RoleIcon = currentRole.icon;

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');
    setSuccess(false);

    if (!email.trim()) {
      setError('يرجى إدخال البريد الإلكتروني');
      return;
    }

    if (!password.trim()) {
      setError('يرجى إدخال كلمة المرور');
      return;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError('صيغة البريد الإلكتروني غير صحيحة');
      return;
    }

    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);
      setSuccess(true);
      setEmail('');
      setPassword('');

      setTimeout(() => {
        setSuccess(false);
      }, 3000);
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center p-4 rtl" dir="rtl">
      {/* خلفية ديكوريّة */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 right-10 w-72 h-72 bg-blue-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse"></div>
        <div className="absolute bottom-20 left-10 w-72 h-72 bg-emerald-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse delay-2000"></div>
      </div>

      {/* المحتوى الرئيسي */}
      <div className="relative w-full max-w-4xl">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
          
          {/* الجزء الأيسر - المعلومات */}
          <div className="hidden lg:flex flex-col justify-center space-y-8">
            <div>
              <h1 className="text-4xl font-bold text-white mb-4 flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-blue-600 rounded-xl flex items-center justify-center">
                  <LogIn className="w-7 h-7 text-white" />
                </div>
                نظام الإدارة الموحد
              </h1>
              <p className="text-blue-200 text-lg leading-relaxed">
                منصة متكاملة لإدارة العمليات والموارد البشرية مع دعم كامل لثلاثة مستويات إدارية متخصصة
              </p>
            </div>

            <div className="space-y-4">
              {roles.map((role) => {
                const Icon = role.icon;
                return (
                  <div key={role.id} className="flex items-start gap-4 p-4 rounded-lg bg-white/10 backdrop-blur-sm border border-white/20 hover:border-white/40 transition-all">
                    <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${role.color} flex items-center justify-center flex-shrink-0`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <p className="text-white font-semibold">{role.name} ({role.label})</p>
                      <p className="text-blue-200 text-sm">{role.description}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* الجزء الأيمن - نموذج التسجيل */}
          <div className="w-full">
            <div className="bg-white rounded-2xl shadow-2xl p-8 md:p-10">
              
              {/* العنوان */}
              <div className="mb-8">
                <h2 className="text-3xl font-bold text-slate-900 mb-2">تسجيل الدخول</h2>
                <p className="text-slate-600">اختر دورك وسجّل دخولك للمتابعة</p>
              </div>

              {/* تحديد الدور */}
              <div className="mb-8">
                <label className="block text-sm font-semibold text-slate-700 mb-4">اختر دورك الوظيفي</label>
                <div className="grid grid-cols-3 gap-3">
                  {roles.map((role) => {
                    const Icon = role.icon;
                    const isSelected = selectedRole === role.id;
                    return (
                      <button
                        key={role.id}
                        onClick={() => setSelectedRole(role.id)}
                        className={`p-4 rounded-lg border-2 transition-all duration-300 flex flex-col items-center gap-2 ${
                          isSelected
                            ? `border-blue-500 ${role.lightColor}`
                            : 'border-slate-200 bg-slate-50 hover:border-slate-300'
                        }`}
                      >
                        <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${role.color} flex items-center justify-center`}>
                          <Icon className="w-5 h-5 text-white" />
                        </div>
                        <span className={`text-xs font-semibold ${isSelected ? role.textColor : 'text-slate-700'}`}>
                          {role.name}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* الرسائل */}
              {error && (
                <div className="mb-6 p-4 rounded-lg bg-red-50 border border-red-200 flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                  <p className="text-red-700 text-sm font-medium">{error}</p>
                </div>
              )}

              {success && (
                <div className="mb-6 p-4 rounded-lg bg-emerald-50 border border-emerald-200 flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
                  <p className="text-emerald-700 text-sm font-medium">تم التحقق بنجاح! سيتم إعادة التوجيه الآن...</p>
                </div>
              )}

              {/* النموذج */}
              <form onSubmit={handleSubmit} className="space-y-5">
                
                {/* البريد الإلكتروني */}
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-2">البريد الإلكتروني</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="admin@example.com"
                    className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all placeholder-slate-400"
                  />
                </div>

                {/* كلمة المرور */}
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-2">كلمة المرور</label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all placeholder-slate-400"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-700 transition-colors"
                    >
                      {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                </div>

                {/* خيارات إضافية */}
                <div className="flex items-center justify-between text-sm">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" className="w-4 h-4 rounded border-slate-300 text-blue-600 cursor-pointer" />
                    <span className="text-slate-700">تذكرني</span>
                  </label>
                  <a href="#" className="text-blue-600 hover:text-blue-700 font-medium transition-colors">
                    هل نسيت كلمة المرور؟
                  </a>
                </div>

                {/* زر التسجيل */}
                <button
                  type="submit"
                  disabled={isLoading}
                  className={`w-full py-3 rounded-lg font-semibold text-white transition-all duration-300 flex items-center justify-center gap-2 ${
                    isLoading
                      ? 'bg-slate-400 cursor-not-allowed'
                      : `bg-gradient-to-r ${currentRole.color} hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0`
                  }`}
                >
                  {isLoading ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      جاري المعالجة...
                    </>
                  ) : (
                    <>
                      <LogIn className="w-5 h-5" />
                      تسجيل الدخول
                    </>
                  )}
                </button>
              </form>

              {/* الرابط السفلي */}
              <p className="text-center text-slate-600 text-sm mt-6">
                ليس لديك حساب؟{' '}
                <a href="#" className="text-blue-600 hover:text-blue-700 font-semibold transition-colors">
                  تواصل مع الإدارة
                </a>
              </p>

              {/* معلومات الحساب التجريبي */}
              <div className="mt-6 pt-6 border-t border-slate-200">
                <p className="text-xs text-slate-600 font-medium mb-3">حسابات تجريبية:</p>
                <div className="space-y-2 text-xs">
                  <div className="flex items-center justify-between p-2 bg-blue-50 rounded">
                    <span className="text-slate-700"><strong>مدير:</strong> admin@demo.com / 123456</span>
                  </div>
                  <div className="flex items-center justify-between p-2 bg-emerald-50 rounded">
                    <span className="text-slate-700"><strong>مندوب:</strong> delegate@demo.com / 123456</span>
                  </div>
                  <div className="flex items-center justify-between p-2 bg-orange-50 rounded">
                    <span className="text-slate-700"><strong>فني:</strong> tech@demo.com / 123456</span>
                  </div>
                </div>
              </div>
            </div>

            {/* الفوتر */}
            <p className="text-center text-blue-200 text-xs mt-6">
              © 2024 نظام الإدارة الموحد. جميع الحقوق محفوظة.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
export default function NewContractRequest() {
  const [formData, setFormData] = React.useState({
    clientName: '',
    clientPhone: '',
    clientEmail: '',
    contractType: '',
    contractValue: '',
    contractDuration: '',
    clientPhoto: null,
    clientPhotoPreview: null,
    bradPhoto: null,
    bradPhotoPreview: null,
    notes: '',
    terms: false,
  });

  const [errors, setErrors] = React.useState({});
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [submitSuccess, setSubmitSuccess] = React.useState(false);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handlePhotoCapture = (e, photoType) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setFormData(prev => ({
          ...prev,
          [photoType]: file,
          [`${photoType}Preview`]: event.target.result
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.clientName.trim()) newErrors.clientName = 'اسم العميل مطلوب';
    if (!formData.clientPhone.trim()) newErrors.clientPhone = 'رقم الهاتف مطلوب';
    if (!formData.clientEmail.trim()) newErrors.clientEmail = 'البريد الإلكتروني مطلوب';
    if (!formData.contractType) newErrors.contractType = 'نوع العهدة مطلوب';
    if (!formData.contractValue) newErrors.contractValue = 'قيمة العهدة مطلوبة';
    if (!formData.clientPhotoPreview) newErrors.clientPhoto = 'صورة العميل مطلوبة';
    if (!formData.bradPhotoPreview) newErrors.bradPhoto = 'صورة البراد مطلوبة';
    if (!formData.terms) newErrors.terms = 'يجب الموافقة على الشروط والأحكام';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setIsSubmitting(true);
    
    // محاكاة إرسال البيانات
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitSuccess(true);
      setTimeout(() => {
        setSubmitSuccess(false);
        setFormData({
          clientName: '',
          clientPhone: '',
          clientEmail: '',
          contractType: '',
          contractValue: '',
          contractDuration: '',
          clientPhoto: null,
          clientPhotoPreview: null,
          bradPhoto: null,
          bradPhotoPreview: null,
          notes: '',
          terms: false,
        });
      }, 2000);
    }, 1500);
  };

  return (
    <div dir="rtl" className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 pb-8">
      {/* رسالة النجاح */}
      {submitSuccess && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-8 max-w-sm w-full shadow-2xl animate-scale-up">
            <div className="flex justify-center mb-4">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
            </div>
            <h3 className="text-xl font-bold text-center text-slate-900 mb-2">تم بنجاح!</h3>
            <p className="text-center text-slate-600">تم إنشاء طلب العهدة الجديدة بنجاح</p>
          </div>
        </div>
      )}

      {/* رأس الصفحة */}
      <div className="bg-white border-b border-slate-200 sticky top-0 z-40 shadow-sm">
        <div className="max-w-2xl mx-auto px-4 py-4 flex items-center gap-3">
          <button className="p-2 hover:bg-slate-100 rounded-lg transition-colors">
            <svg className="w-6 h-6 text-slate-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-slate-900">طلب عهدة جديدة</h1>
            <p className="text-sm text-slate-500 mt-1">أضف تفاصيل العهدة والعميل</p>
          </div>
        </div>
      </div>

      {/* المحتوى الرئيسي */}
      <div className="max-w-2xl mx-auto px-4 py-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          
          {/* قسم معلومات العميل */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 space-y-5">
            <div className="flex items-center gap-3 pb-4 border-b border-slate-100">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h2 className="text-lg font-bold text-slate-900">بيانات العميل</h2>
            </div>

            {/* اسم العميل */}
            <div>
              <label className="block text-sm font-semibold text-slate-900 mb-2">اسم العميل</label>
              <input
                type="text"
                name="clientName"
                value={formData.clientName}
                onChange={handleInputChange}
                placeholder="أدخل اسم العميل الكامل"
                className={`w-full px-4 py-3 rounded-lg border-2 transition-all focus:outline-none ${
                  errors.clientName
                    ? 'border-red-500 focus:border-red-600 bg-red-50'
                    : 'border-slate-300 focus:border-blue-500'
                }`}
              />
              {errors.clientName && <p className="text-red-600 text-sm mt-1.5 flex items-center gap-1">
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M18.101 12.93a1 1 0 00-1.414-1.414L10 14.586 7.313 11.899a1 1 0 00-1.414 1.414l4 4a1 1 0 001.414 0l8-8z" clipRule="evenodd" />
                </svg>
                {errors.clientName}
              </p>}
            </div>

            {/* رقم الهاتف */}
            <div>
              <label className="block text-sm font-semibold text-slate-900 mb-2">رقم الهاتف</label>
              <input
                type="tel"
                name="clientPhone"
                value={formData.clientPhone}
                onChange={handleInputChange}
                placeholder="مثال: 966501234567"
                className={`w-full px-4 py-3 rounded-lg border-2 transition-all focus:outline-none ${
                  errors.clientPhone
                    ? 'border-red-500 focus:border-red-600 bg-red-50'
                    : 'border-slate-300 focus:border-blue-500'
                }`}
              />
              {errors.clientPhone && <p className="text-red-600 text-sm mt-1.5">{errors.clientPhone}</p>}
            </div>

            {/* البريد الإلكتروني */}
            <div>
              <label className="block text-sm font-semibold text-slate-900 mb-2">البريد الإلكتروني</label>
              <input
                type="email"
                name="clientEmail"
                value={formData.clientEmail}
                onChange={handleInputChange}
                placeholder="example@company.com"
                className={`w-full px-4 py-3 rounded-lg border-2 transition-all focus:outline-none ${
                  errors.clientEmail
                    ? 'border-red-500 focus:border-red-600 bg-red-50'
                    : 'border-slate-300 focus:border-blue-500'
                }`}
              />
              {errors.clientEmail && <p className="text-red-600 text-sm mt-1.5">{errors.clientEmail}</p>}
            </div>
          </div>

          {/* قسم تفاصيل العهدة */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 space-y-5">
            <div className="flex items-center gap-3 pb-4 border-b border-slate-100">
              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h2 className="text-lg font-bold text-slate-900">تفاصيل العهدة</h2>
            </div>

            {/* نوع العهدة */}
            <div>
              <label className="block text-sm font-semibold text-slate-900 mb-2">نوع العهدة</label>
              <select
                name="contractType"
                value={formData.contractType}
                onChange={handleInputChange}
                className={`w-full px-4 py-3 rounded-lg border-2 transition-all focus:outline-none ${
                  errors.contractType
                    ? 'border-red-500 focus:border-red-600 bg-red-50'
                    : 'border-slate-300 focus:border-blue-500'
                }`}
              >
                <option value="">اختر نوع العهدة</option>
                <option value="equipment">معدات</option>
                <option value="technology">تكنولوجيا</option>
                <option value="supplies">مستلزمات</option>
                <option value="vehicles">مركبات</option>
                <option value="other">أخرى</option>
              </select>
              {errors.contractType && <p className="text-red-600 text-sm mt-1.5">{errors.contractType}</p>}
            </div>

            {/* قيمة العهدة */}
            <div>
              <label className="block text-sm font-semibold text-slate-900 mb-2">قيمة العهدة (ريال)</label>
              <input
                type="number"
                name="contractValue"
                value={formData.contractValue}
                onChange={handleInputChange}
                placeholder="0.00"
                className={`w-full px-4 py-3 rounded-lg border-2 transition-all focus:outline-none ${
                  errors.contractValue
                    ? 'border-red-500 focus:border-red-600 bg-red-50'
                    : 'border-slate-300 focus:border-blue-500'
                }`}
              />
              {errors.contractValue && <p className="text-red-600 text-sm mt-1.5">{errors.contractValue}</p>}
            </div>

            {/* مدة العهدة */}
            <div>
              <label className="block text-sm font-semibold text-slate-900 mb-2">مدة العهدة (بالأيام)</label>
              <input
                type="number"
                name="contractDuration"
                value={formData.contractDuration}
                onChange={handleInputChange}
                placeholder="مثال: 30"
                className="w-full px-4 py-3 rounded-lg border-2 border-slate-300 focus:border-blue-500 focus:outline-none transition-all"
              />
            </div>

            {/* ملاحظات */}
            <div>
              <label className="block text-sm font-semibold text-slate-900 mb-2">ملاحظات إضافية</label>
              <textarea
                name="notes"
                value={formData.notes}
                onChange={handleInputChange}
                placeholder="أضف أي ملاحظات أو شروط خاصة..."
                rows="4"
                className="w-full px-4 py-3 rounded-lg border-2 border-slate-300 focus:border-blue-500 focus:outline-none transition-all resize-none"
              />
            </div>
          </div>

          {/* قسم الصور */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 space-y-5">
            <div className="flex items-center gap-3 pb-4 border-b border-slate-100">
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                <svg className="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
              </div>
              <h2 className="text-lg font-bold text-slate-900">الصور المطلوبة</h2>
            </div>

            {/* صورة العميل */}
            <div>
              <label className="block text-sm font-semibold text-slate-900 mb-3">صورة العميل</label>
              <div className="relative">
                <input
                  type="file"
                  accept="image/*"
                  capture="environment"
                  onChange={(e) => handlePhotoCapture(e, 'clientPhoto')}
                  className="hidden"
                  id="clientPhotoInput"
                />
                {formData.clientPhotoPreview ? (
                  <div className="relative rounded-xl overflow-hidden shadow-md">
                    <img src={formData.clientPhotoPreview} alt="صورة العميل" className="w-full h-64 object-cover" />
                    <label htmlFor="clientPhotoInput" className="absolute inset-0 bg-black/0 hover:bg-black/20 transition-colors flex items-center justify-center cursor-pointer">
                      <svg className="w-8 h-8 text-white opacity-0 hover:opacity-100 transition-opacity" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                      </svg>
                    </label>
                  </div>
                ) : (
                  <label htmlFor="clientPhotoInput" className={`block border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all ${
                    errors.clientPhoto
                      ? 'border-red-400 bg-red-50'
                      : 'border-slate-300 bg-slate-50 hover:border-blue-400 hover:bg-blue-50'
                  }`}>
                    <svg className={`w-12 h-12 mx-auto mb-3 ${errors.clientPhoto ? 'text-red-400' : 'text-slate-400'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                    <p className={`font-semibold ${errors.clientPhoto ? 'text-red-600' : 'text-slate-900'}`}>اضغط لالتقاط صورة</p>
                    <p className="text-sm text-slate-500 mt-1">أو اختر صورة من المعرض</p>
                  </label>
                )}
                {errors.clientPhoto && <p className="text-red-600 text-sm mt-2">{errors.clientPhoto}</p>}
              </div>
            </div>

            {/* صورة البراد */}
            <div>
              <label className="block text-sm font-semibold text-slate-900 mb-3">صورة البراد/المنتج</label>
              <div className="relative">
                <input
                  type="file"
                  accept="image/*"
                  capture="environment"
                  onChange={(e) => handlePhotoCapture(e, 'bradPhoto')}
                  className="hidden"
                  id="bradPhotoInput"
                />
                {formData.bradPhotoPreview ? (
                  <div className="relative rounded-xl overflow-hidden shadow-md">
                    <img src={formData.bradPhotoPreview} alt="صورة البراد" className="w-full h-64 object-cover" />
                    <label htmlFor="bradPhotoInput" className="absolute inset-0 bg-black/0 hover:bg-black/20 transition-colors flex items-center justify-center cursor-pointer">
                      <svg className="w-8 h-8 text-white opacity-0 hover:opacity-100 transition-opacity" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                      </svg>
                    </label>
                  </div>
                ) : (
                  <label htmlFor="bradPhotoInput" className={`block border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all ${
                    errors.bradPhoto
                      ? 'border-red-400 bg-red-50'
                      : 'border-slate-300 bg-slate-50 hover:border-blue-400 hover:bg-blue-50'
                  }`}>
                    <svg className={`w-12 h-12 mx-auto mb-3 ${errors.bradPhoto ? 'text-red-400' : 'text-slate-400'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                    <p className={`font-semibold ${errors.bradPhoto ? 'text-red-600' : 'text-slate-900'}`}>اضغط لالتقاط صورة</p>
                    <p className="text-sm text-slate-500 mt-1">أو اختر صورة من المعرض</p>
                  </label>
                )}
                {errors.bradPhoto && <p className="text-red-600 text-sm mt-2">{errors.bradPhoto}</p>}
              </div>
            </div>
          </div>

          {/* الشروط والأحكام */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
            <label className="flex items-start gap-3 cursor-pointer">
              <input
                type="checkbox"
                name="terms"
                checked={formData.terms}
                onChange={handleInputChange}
                className={`w-5 h-5 rounded border-2 mt-1 transition-all cursor-pointer ${
                  errors.terms
                    ? 'border-red-500 accent-red-600'
                    : 'border-slate-300 accent-blue-600'
                }`}
              />
              <div className="flex-1 pt-0.5">
                <p className="text-sm text-slate-700">
                  أوافق على <span className="font-semibold text-blue-600">الشروط والأحكام</span> وتصريح معالجة البيانات الشخصية
                </p>
                {errors.terms && <p className="text-red-600 text-sm mt-1">{errors.terms}</p>}
              </div>
            </label>
          </div>

          {/* الأزرار */}
          <div className="flex gap-3 sticky bottom-0 bg-gradient-to-t from-slate-100 to-transparent pt-4 pb-2">
            <button
              type="button"
              className="flex-1 px-6 py-3 rounded-lg border-2 border-slate-300 text-slate-900 font-semibold hover:bg-slate-50 transition-colors"
            >
              إلغاء
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 px-6 py-3 rounded-lg bg-gradient-to-r from-blue-600 to-blue-700 text-white font-semibold hover:shadow-lg disabled:opacity-75 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2"
            >
              {isSubmitting ? (
                <>
                  <svg className="w-5 h-5 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                  </svg>
                  جاري الإرسال...
                </>
              ) : (
                <>
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                  </svg>
                  إنشاء العهدة
                </>
              )}
            </button>
          </div>
        </form>
      </div>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
        
        * {
          font-family: 'Inter', sans-serif;
        }
        
        @keyframes scale-up {
          from {
            opacity: 0;
            transform: scale(0.95);
          }
          to {
            opacity: 1;
            transform: scale(1);
          }
        }
        
        .animate-scale-up {
          animation: scale-up 0.3s ease-out;
        }
      `}</style>
    </div>
  );
}
import React, { useState } from 'react';
import { AlertCircle, CheckCircle2, Clock, MapPin, Phone, MessageSquare, Filter, Search, Plus } from 'lucide-react';

export default function MaintenanceTicketsList() {
  const [tickets, setTickets] = useState([
    {
      id: 'TK-2024-001',
      title: 'عطل في نظام التكييف',
      location: 'مكتب الإدارة - الطابق الثالث',
      priority: 'high',
      status: 'urgent',
      date: '2024-01-15',
      time: '09:30',
      client: 'أحمد محمد',
      phone: '+966501234567',
      description: 'تسرب مياه من وحدة التكييف المركزية',
      estimatedTime: '2 ساعة'
    },
    {
      id: 'TK-2024-002',
      title: 'صيانة الثلاجات التجارية',
      location: 'المقهى - الطابق الأول',
      priority: 'medium',
      status: 'active',
      date: '2024-01-15',
      time: '11:00',
      client: 'فاطمة علي',
      phone: '+966502345678',
      description: 'فحص شامل وتنظيف وحدات التبريد',
      estimatedTime: '1.5 ساعة'
    },
    {
      id: 'TK-2024-003',
      title: 'إصلاح باب المصعد',
      location: 'المدخل الرئيسي',
      priority: 'high',
      status: 'urgent',
      date: '2024-01-15',
      time: '14:15',
      client: 'سارة حسن',
      phone: '+966503456789',
      description: 'المصعد لا يغلق الباب بشكل صحيح',
      estimatedTime: '45 دقيقة'
    },
    {
      id: 'TK-2024-004',
      title: 'استبدال مرشحات الهواء',
      location: 'غرفة الخادم',
      priority: 'low',
      status: 'pending',
      date: '2024-01-16',
      time: '10:00',
      client: 'محمود إبراهيم',
      phone: '+966504567890',
      description: 'تغيير مرشحات نظام التهوية الدورية',
      estimatedTime: '30 دقيقة'
    },
    {
      id: 'TK-2024-005',
      title: 'صيانة المضخات المائية',
      location: 'غرفة الأساسات',
      priority: 'medium',
      status: 'active',
      date: '2024-01-16',
      time: '13:30',
      client: 'ليلى أحمد',
      phone: '+966505678901',
      description: 'فحص الضغط والتدفق واستبدال الأختام',
      estimatedTime: '2 ساعات'
    }
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [selectedTicket, setSelectedTicket] = useState(null);

  const getPriorityColor = (priority) => {
    switch(priority) {
      case 'high': return 'bg-red-50 border-red-200';
      case 'medium': return 'bg-amber-50 border-amber-200';
      case 'low': return 'bg-green-50 border-green-200';
      default: return 'bg-gray-50 border-gray-200';
    }
  };

  const getPriorityBadgeColor = (priority) => {
    switch(priority) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-amber-100 text-amber-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status) => {
    switch(status) {
      case 'urgent': return <AlertCircle className="w-5 h-5 text-red-600" />;
      case 'active': return <Clock className="w-5 h-5 text-blue-600" />;
      case 'pending': return <Clock className="w-5 h-5 text-amber-600" />;
      case 'completed': return <CheckCircle2 className="w-5 h-5 text-green-600" />;
      default: return <Clock className="w-5 h-5 text-gray-600" />;
    }
  };

  const getStatusLabel = (status) => {
    switch(status) {
      case 'urgent': return 'عاجل';
      case 'active': return 'قيد العمل';
      case 'pending': return 'قيد الانتظار';
      case 'completed': return 'مكتمل';
      default: return status;
    }
  };

  const filteredTickets = tickets.filter(ticket => {
    const matchesSearch = ticket.title.includes(searchTerm) || 
                         ticket.id.includes(searchTerm) ||
                         ticket.client.includes(searchTerm);
    const matchesFilter = filterStatus === 'all' || ticket.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  const urgentCount = tickets.filter(t => t.status === 'urgent').length;
  const activeCount = tickets.filter(t => t.status === 'active').length;

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white" dir="rtl">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-white border-b border-blue-100 shadow-sm">
        <div className="px-4 py-4 max-w-4xl mx-auto">
          <div className="flex items-center justify-between mb-4">
            <div className="flex-1">
              <h1 className="text-2xl font-bold text-gray-900">تذاكر الصيانة</h1>
              <p className="text-sm text-gray-500 mt-1">المسار: /technician/tickets</p>
            </div>
            <button className="p-2.5 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition-colors shadow-lg">
              <Plus className="w-6 h-6" />
            </button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-2 mb-4">
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-center">
              <div className="text-2xl font-bold text-red-600">{urgentCount}</div>
              <div className="text-xs text-red-700 font-medium">عاجل</div>
            </div>
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-center">
              <div className="text-2xl font-bold text-blue-600">{activeCount}</div>
              <div className="text-xs text-blue-700 font-medium">قيد العمل</div>
            </div>
            <div className="bg-green-50 border border-green-200 rounded-lg p-3 text-center">
              <div className="text-2xl font-bold text-green-600">{tickets.length}</div>
              <div className="text-xs text-green-700 font-medium">الإجمالي</div>
            </div>
          </div>

          {/* Search */}
          <div className="relative mb-3">
            <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="ابحث عن التذاكر..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pr-10 pl-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
            />
          </div>

          {/* Filters */}
          <div className="flex gap-2 overflow-x-auto pb-2">
            {['all', 'urgent', 'active', 'pending'].map(status => (
              <button
                key={status}
                onClick={() => setFilterStatus(status)}
                className={`px-4 py-2 rounded-full whitespace-nowrap text-sm font-medium transition-all ${
                  filterStatus === status
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                {status === 'all' ? 'الكل' : status === 'urgent' ? 'عاجل' : status === 'active' ? 'قيد العمل' : 'قيد الانتظار'}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Tickets List */}
      <div className="px-4 py-4 max-w-4xl mx-auto pb-20">
        {filteredTickets.length === 0 ? (
          <div className="text-center py-12">
            <AlertCircle className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500 font-medium">لا توجد تذاكر متطابقة</p>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredTickets.map((ticket) => (
              <div
                key={ticket.id}
                onClick={() => setSelectedTicket(selectedTicket?.id === ticket.id ? null : ticket)}
                className={`${getPriorityColor(ticket.priority)} border rounded-xl overflow-hidden cursor-pointer transition-all hover:shadow-md`}
              >
                {/* Main Content */}
                <div className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs font-bold text-gray-600 bg-white px-2 py-1 rounded">
                          {ticket.id}
                        </span>
                        <span className={`text-xs font-bold px-2 py-1 rounded ${getPriorityBadgeColor(ticket.priority)}`}>
                          {ticket.priority === 'high' ? 'أولوية عالية' : ticket.priority === 'medium' ? 'متوسطة' : 'منخفضة'}
                        </span>
                      </div>
                      <h3 className="text-base font-bold text-gray-900">{ticket.title}</h3>
                    </div>
                    <div className="flex items-center gap-2">
                      {getStatusIcon(ticket.status)}
                      <span className="text-xs font-bold text-gray-700 bg-white px-2 py-1 rounded">
                        {getStatusLabel(ticket.status)}
                      </span>
                    </div>
                  </div>

                  {/* Quick Info */}
                  <div className="grid grid-cols-2 gap-3 mb-3">
                    <div className="flex items-center gap-2 text-sm">
                      <MapPin className="w-4 h-4 text-blue-600 flex-shrink-0" />
                      <span className="text-gray-700 truncate">{ticket.location}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Clock className="w-4 h-4 text-amber-600 flex-shrink-0" />
                      <span className="text-gray-700">{ticket.time}</span>
                    </div>
                  </div>

                  {/* Client Info */}
                  <div className="flex items-center justify-between bg-white bg-opacity-60 rounded-lg p-3 mb-3">
                    <div>
                      <p className="text-xs text-gray-600 font-medium">العميل</p>
                      <p className="text-sm font-bold text-gray-900">{ticket.client}</p>
                    </div>
                    <button className="p-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 transition-colors">
                      <Phone className="w-5 h-5" />
                    </button>
                  </div>

                  {/* Estimated Time */}
                  <div className="bg-white bg-opacity-60 rounded-lg p-3 flex items-center justify-between">
                    <span className="text-xs text-gray-600 font-medium">الوقت المتوقع</span>
                    <span className="text-sm font-bold text-blue-600">{ticket.estimatedTime}</span>
                  </div>
                </div>

                {/* Expanded Details */}
                {selectedTicket?.id === ticket.id && (
                  <div className="border-t border-current border-opacity-20 px-4 py-4 bg-white bg-opacity-40">
                    <div className="space-y-4">
                      <div>
                        <p className="text-xs text-gray-600 font-bold mb-2">الوصف</p>
                        <p className="text-sm text-gray-800 leading-relaxed">{ticket.description}</p>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div className="bg-white rounded-lg p-3">
                          <p className="text-xs text-gray-600 font-medium mb-1">التاريخ</p>
                          <p className="text-sm font-bold text-gray-900">{ticket.date}</p>
                        </div>
                        <div className="bg-white rounded-lg p-3">
                          <p className="text-xs text-gray-600 font-medium mb-1">الهاتف</p>
                          <p className="text-sm font-bold text-blue-600 truncate">{ticket.phone}</p>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <button className="flex-1 bg-blue-600 text-white py-2.5 rounded-lg font-bold hover:bg-blue-700 transition-colors flex items-center justify-center gap-2">
                          <MessageSquare className="w-4 h-4" />
                          قبول التذكرة
                        </button>
                        <button className="flex-1 bg-gray-300 text-gray-700 py-2.5 rounded-lg font-bold hover:bg-gray-400 transition-colors">
                          تأجيل
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Bottom Action Bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg">
        <div className="max-w-4xl mx-auto px-4 py-3 flex gap-2">
          <button className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-lg font-bold hover:bg-gray-200 transition-colors">
            <Filter className="w-5 h-5 inline mr-2" />
            تصفية
          </button>
          <button className="flex-1 bg-blue-600 text-white py-3 rounded-lg font-bold hover:bg-blue-700 transition-colors shadow-lg">
            تحديث القائمة
          </button>
        </div>
      </div>
    </div>
  );
}
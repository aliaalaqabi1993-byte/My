import React, { useMemo, useState } from 'react';

export default function MaintenanceTickets() {
  // RTL Arabic UI with responsive, MD3-inspired layout using Tailwind CSS only
  // Fonts: Tajawal/Inter prioritized via inline style (if loaded in the host app)
  const [query, setQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [tickets, setTickets] = useState(seedTickets);

  // Arabic labels and color logic
  const statusArabic = {
    'Open': 'مفتوح',
    'In Progress': 'قيد التنفيذ',
    'Closed': 'مغلقة'
  };

  const statusColor = (s) => {
    if (s === 'Open' || s === 'In Progress') return 'text-emerald-700';
    if (s === 'Closed') return 'text-red-600';
    return 'text-gray-600';
  };

  // Compute simple statistics for the header cards
  const stats = useMemo(() => {
    const total = tickets.length;
    const open = tickets.filter((t) => t.status === 'Open').length;
    const inProg = tickets.filter((t) => t.status === 'In Progress').length;
    const closed = tickets.filter((t) => t.status === 'Closed').length;
    return { total, open, inProg, closed };
  }, [tickets]);

  // Filter tickets by search query and status
  const filteredTickets = useMemo(() => {
    return tickets
      .filter((t) => {
        if (statusFilter !== 'All' && t.status !== statusFilter) return false;
        if (!query) return true;
        const q = query.toLowerCase();
        return (
          t.id.toLowerCase().includes(q) ||
          t.title.toLowerCase().includes(q) ||
          t.location.toLowerCase().includes(q)
        );
      })
      .sort((a, b) => {
        // Open > In Progress > Closed for quick scanning
        const order = { 'Open': 0, 'In Progress': 1, 'Closed': 2 };
        return order[a.status] - order[b.status];
      });
  }, [tickets, query, statusFilter]);

  // Map markers: aggregate open tickets by city for a lightweight interactive map
  const cityCoords = {
    الرياض: { x: 420, y: 200 },
    القاهرة: { x: 320, y: 140 },
    دبي: { x: 520, y: 110 },
    جدة: { x: 460, y: 190 },
    الإسكندرية: { x: 300, y: 120 }
  };

  // Aggregate open tickets per city
  const cityCounts = useMemo(() => {
    const counts = {};
    tickets.forEach((t) => {
      if (t.status === 'Open' || t.status === 'In Progress') {
        counts[t.location] = (counts[t.location] || 0) + 1;
      }
    });
    return counts;
  }, [tickets]);

  const markers = Object.entries(cityCounts).map(([city, count]) => {
    const c = cityCoords[city];
    return {
      city,
      count,
      x: c?.x ?? 100,
      y: c?.y ?? 100,
      color: count > 0 ? '#16a34a' : '#94a3b8'
    };
  });

  // Interaction: clicking a marker filters by city
  const [markerTooltip, setMarkerTooltip] = useState(null);

  // Update ticket status
  const updateTicketStatus = (id, newStatus) => {
    setTickets((prev) =>
      prev.map((t) => (t.id === id ? { ...t, status: newStatus } : t))
    );
  };

  // Responsive typography: Arabic-friendly font family
  const fontFamily = "'Tajawal', 'Inter', system-ui, -apple-system, Roboto, 'Segoe UI', sans-serif";

  return (
    <div className="min-h-screen bg-gray-50" dir="rtl" style={{ fontFamily }}>
      {/* Header / Breadcrumb */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <span className="inline-flex items-center justify-center h-9 w-9 rounded-full bg-blue-600 text-white font-semibold">
              🧱
            </span>
            <div>
              <div className="text-sm text-gray-500">لوحة الإدارة</div>
              <h1 className="text-xl md:text-2xl font-semibold text-gray-800">صفحة تذاكر الصيانة</h1>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-500 hidden sm:block">المظهر: حلال اللون الأزرق الرسمي</span>
            <button className="px-4 py-2 rounded-xl bg-blue-600 text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500">
              إضافة تذكرة
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left pane: Stats & Filters (col-span-4 on large screens) */}
        <section className="lg:col-span-4 bg-white rounded-xl shadow-sm border border-gray-200 p-4">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
            <div className="bg-blue-50 border border-blue-100 rounded-xl p-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-600">إجمالي التذاكر</span>
                <span className="text-xs px-2 py-1 rounded-full bg-blue-100 text-blue-700">الأنظمة</span>
              </div>
              <div className="mt-2 text-2xl font-bold text-gray-800">{stats.total}</div>
            </div>
            <div className="bg-green-50 border border-green-100 rounded-xl p-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-600">مفتوحة</span>
              </div>
              <div className="mt-2 text-2xl font-bold text-gray-800">{stats.open}</div>
              <div className="mt-1 text-xs text-green-700">نشطة حالياً</div>
            </div>
            <div className="bg-yellow-50 border border-yellow-100 rounded-xl p-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-600">قيد التنفيذ</span>
              </div>
              <div className="mt-2 text-2xl font-bold text-gray-800">{stats.inProg}</div>
              <div className="mt-1 text-xs text-yellow-700">تحديث مستمر</div>
            </div>
          </div>

          {/* Search & Filters */}
          <div className="mt-2">
            <label className="block text-sm font-medium text-gray-700 mb-1">ابحث في التذاكر</label>
            <div className="flex items-center gap-2">
              <div className="relative w-full">
                <input
                  aria-label="بحث عن تذكرة"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="مثلاً: MT-1001، صيانة المصعد، القاهرة"
                  className="w-full pl-10 pr-3 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                />
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
                  🔎
                </span>
              </div>
            </div>
          </div>

          <div className="mt-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">تصفية الحالة</label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full py-2 px-3 rounded-lg border border-gray-300 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="All">الكل</option>
              <option value="Open">مفتوح</option>
              <option value="In Progress">قيد التنفيذ</option>
              <option value="Closed">مغلقة</option>
            </select>
          </div>

          <div className="mt-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-semibold text-gray-700">إحصاءات المواقع</span>
              <span className="text-xs text-gray-500">خرائط تفاعلية بسيطة</span>
            </div>
            <div className="rounded-lg overflow-hidden border border-gray-200">
              {/* Simple city counts chips */}
              <div className="flex flex-wrap gap-2 p-2">
                {Object.keys(cityCoords).map((city) => {
                  const v = tickets.filter((t) => t.location === city && t.status !== 'Closed').length;
                  const color = v > 0 ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500';
                  return (
                    <span key={city} className={`text-xs px-3 py-1 rounded-full ${color} border`}>
                      {city} • {v}
                    </span>
                  );
                })}
              </div>
            </div>
          </div>
        </section>

        {/* Right pane: Map & Table (col-span-8 on large screens) */}
        <section className="lg:col-span-8 bg-white rounded-xl shadow-sm border border-gray-200 p-4 overflow-hidden">
          {/* Map Card */}
          <div className="mb-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="h-5 w-5 inline-flex items-center justify-center rounded-full bg-blue-600 text-white">
                  🗺️
                </span>
                <h2 className="text-lg font-semibold text-gray-800">خرائط توزيع التذاكر المفتوحة</h2>
              </div>
              <span className="text-xs text-gray-500">إحداثيات مبسطة وليست خريطة فعلية</span>
            </div>
            <div className="w-full overflow-hidden rounded-xl border border-gray-200 bg-slate-50">
              <MapChart
                markers={markers}
                onMarkerClick={(city) => setQuery(city)}
                tooltip={markerTooltip}
              />
            </div>
          </div>

          {/* Tickets Table */}
          <div className="mt-2">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium text-gray-600">قائمة التذاكر</span>
                <span className="text-xs text-gray-500">عرض/تعديل حالة التذكرة بالدقة والسرعة</span>
              </div>
              <div className="text-xs text-gray-500">{filteredTickets.length} نتائج</div>
            </div>

            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">معرف التذكرة</th>
                    <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">العنصر</th>
                    <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">الموقع</th>
                    <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">الأولوية</th>
                    <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">الحالة</th>
                    <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">تاريخ الإنشاء</th>
                    <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">إجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {filteredTickets.map((t) => (
                    <tr key={t.id}>
                      <td className="px-4 py-3 text-sm text-gray-700 whitespace-nowrap">{t.id}</td>
                      <td className="px-4 py-3 text-sm text-gray-700">{t.title}</td>
                      <td className="px-4 py-3 text-sm text-gray-700">{t.location}</td>
                      <td className="px-4 py-3 text-sm">
                        <span className={`px-2 py-1 rounded-lg text-xs ${t.priority === 'عالي' ? 'bg-red-100 text-red-700' : t.priority === 'متوسط' ? 'bg-yellow-100 text-yellow-700' : 'bg-green-100 text-green-700'}`}>
                          {t.priority}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm">
                        <span className={`px-2 py-1 rounded-lg text-xs ${statusColor(t.status)}`}>
                          {statusArabic[t.status]}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-600">{formatDate(t.createdAt)}</td>
                      <td className="px-4 py-3 text-sm text-gray-700">
                        <div className="flex items-center gap-2 justify-end">
                          <button
                            onClick={() =>
                              updateTicketStatus(t.id, t.status === 'Closed' ? 'Open' : 'Closed')
                            }
                            className="px-2 py-1 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 text-xs"
                          >
                            {t.status === 'Closed' ? 'إعادة فتح' : 'إغلاق'}
                          </button>
                          <button
                            className="px-2 py-1 rounded-lg bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs"
                            onClick={() => setQuery(t.id)}
                          >
                            عرض
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                  {filteredTickets.length === 0 && (
                    <tr>
                      <td className="px-4 py-6 text-center text-sm text-gray-500" colSpan={7}>
                        لا توجد نتائج مطابقة للبحث الحالي.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

// Helper components and data

function MapChart({ markers, onMarkerClick, tooltip }) {
  // Simple illustrative map (SVG) with markers
  return (
    <svg viewBox="0 0 600 350" width="100%" height="100%" role="img" aria-label="Map of ticket distribution" className="block bg-white">
      {/* Map background */}
      <defs>
        <linearGradient id="bg" x1="0" x2="0" y1="0" y2="1">
          <stop stopColor="#f8fbff" offset="0" />
          <stop stopColor="#eef4ff" offset="1" />
        </linearGradient>
      </defs>
      <rect x="0" y="0" width="600" height="350" fill="url(#bg)" />
      {/* Simple stylized landmass */}
      <path d="M40,180 C120,120 200,150 260,130 C320,110 360,140 420,150 C480,160 520,210 560,230 L560,350 L40,350Z" fill="rgba(25, 99, 210, 0.08)" stroke="rgba(25,99,210,0.25)" />
      {/* Marker circle for each city */}
      {markers.map((m, idx) => (
        <g key={idx} transform={`translate(${m.x}, ${m.y})`}>
          <circle cx="0" cy="0" r="9" fill={m.color} stroke="#fff" strokeWidth="2" style={{ cursor: 'pointer' }} />
          <circle cx="0" cy="0" r="14" fill="transparent" stroke="rgba(14, 30, 60, 0.15)" strokeWidth="2" style={{ cursor: 'pointer' }} 
            onMouseEnter={() => {
              // lightweight tooltip-like behavior (no external libs)
            }}
            onClick={() => onMarkerClick?.(m.city)}
          />
          <text x="12" y="-12" fontSize="11" fill="#334155" textAnchor="start">
            {m.city}
          </text>
          <text x="12" y="0" fontSize="11" fill="#374151" textAnchor="start">
            {m.count}
          </text>
        </g>
      ))}
      {/* Legend */}
      <g transform="translate(12,310)">
        <rect width="170" height="28" rx="6" fill="white" stroke="rgba(0,0,0,0.08)" />
        <text x="8" y="18" fontSize="11" fill="#64748b">المواقع: عدّاد التذاكر المفتوحة</text>
      </g>
    </svg>
  );
}

function formatDate(dateString) {
  // Expecting ISO-like date in seed data
  try {
    const d = new Date(dateString);
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    // Locale Arabic-friendly format
    return d.toLocaleDateString('ar-EG', options);
  } catch {
    return dateString;
  }
}

// Seed data: مدخلات تجريبية ذات معنى
function seedTickets() {
  return [
    {
      id: 'MT-1001',
      title: 'تلف في المصعد في مبنى الإدارة',
      location: 'الرياض',
      priority: 'عالي',
      status: 'Open',
      createdAt: '2026-04-25T08:23:00Z'
    },
    {
      id: 'MT-1002',
      title: 'إضاءة خلفية غير متوافقة في القاعة الكبرى',
      location: 'القاهرة',
      priority: 'متوسط',
      status: 'In Progress',
      createdAt: '2026-04-28T11:14:00Z'
    },
    {
      id: 'MT-1003',
      title: 'تسرب ماء في حمام العمال',
      location: 'جدة',
      priority: 'عالي',
      status: 'Open',
      createdAt: '2026-04-29T09:45:00Z'
    },
    {
      id: 'MT-1004',
      title: 'فشل مكيف في غرفة الخوادم',
      location: 'الإسكندرية',
      priority: 'عالي',
      status: 'Closed',
      createdAt: '2026-03-15T15:20:00Z'
    },
    {
      id: 'MT-1005',
      title: 'إغلاق باب الطوارئ يعلق القاعدة',
      location: 'الرياض',
      priority: 'متوسط',
      status: 'Open',
      createdAt: '2026-04-21T13:30:00Z'
    },
    {
      id: 'MT-1006',
      title: 'كاميرا الأمان الخلفية تفصل أحياناً',
      location: 'دبي',
      priority: 'منخفض',
      status: 'In Progress',
      createdAt: '2026-04-20T10:10:00Z'
    },
    {
      id: 'MT-1007',
      title: 'إشعال إنذار الحريق بشكل عشوائي',
      location: 'القاهرة',
      priority: 'متوسط',
      status: 'Open',
      createdAt: '2026-04-26T07:50:00Z'
    },
    {
      id: 'MT-1008',
      title: 'انقطاع الإنترنت في قسم الهندسة',
      location: 'الرياض',
      priority: 'عالي',
      status: 'Closed',
      createdAt: '2026-03-30T09:00:00Z'
    }
  ];
}
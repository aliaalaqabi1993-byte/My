import React, { useState } from 'react';
import { ChevronDown, Plus, Edit2, Trash2, Search, Filter, Eye, EyeOff, Check, X, Shield, User, Mail, Phone, Calendar, AlertCircle } from 'lucide-react';

export default function UserManagement() {
  const [users, setUsers] = useState([
    { id: 1, name: 'أحمد محمد', email: 'ahmed@example.com', phone: '+966501234567', role: 'مدير النظام', status: 'نشط', joinDate: '2024-01-15', permissions: ['قراءة', 'كتابة', 'حذف'] },
    { id: 2, name: 'فاطمة علي', email: 'fatima@example.com', phone: '+966502345678', role: 'محرر المحتوى', status: 'نشط', joinDate: '2024-02-20', permissions: ['قراءة', 'كتابة'] },
    { id: 3, name: 'محمود سالم', email: 'mahmoud@example.com', phone: '+966503456789', role: 'مراجع', status: 'معطل', joinDate: '2024-03-10', permissions: ['قراءة'] },
    { id: 4, name: 'ليلى خالد', email: 'layla@example.com', phone: '+966504567890', role: 'مدير المشاريع', status: 'نشط', joinDate: '2024-01-25', permissions: ['قراءة', 'كتابة'] },
    { id: 5, name: 'علي حسن', email: 'ali@example.com', phone: '+966505678901', role: 'محلل البيانات', status: 'نشط', joinDate: '2024-02-08', permissions: ['قراءة'] },
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [filterRole, setFilterRole] = useState('الكل');
  const [filterStatus, setFilterStatus] = useState('الكل');
  const [showModal, setShowModal] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(null);

  const roles = ['مدير النظام', 'محرر المحتوى', 'مراجع', 'مدير المشاريع', 'محلل البيانات', 'مستخدم عادي'];
  const statuses = ['نشط', 'معطل', 'قيد الانتظار'];

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.name.includes(searchTerm) || user.email.includes(searchTerm);
    const matchesRole = filterRole === 'الكل' || user.role === filterRole;
    const matchesStatus = filterStatus === 'الكل' || user.status === filterStatus;
    return matchesSearch && matchesRole && matchesStatus;
  });

  const handleAddUser = () => {
    setEditingUser(null);
    setShowModal(true);
  };

  const handleEditUser = (user) => {
    setEditingUser(user);
    setShowModal(true);
  };

  const handleDeleteUser = (id) => {
    setUsers(users.filter(u => u.id !== id));
    setShowDeleteConfirm(null);
  };

  const getStatusColor = (status) => {
    if (status === 'نشط') return 'bg-green-100 text-green-800 border border-green-300';
    if (status === 'معطل') return 'bg-red-100 text-red-800 border border-red-300';
    return 'bg-yellow-100 text-yellow-800 border border-yellow-300';
  };

  const getStatusIcon = (status) => {
    if (status === 'نشط') return <Check className="w-4 h-4" />;
    if (status === 'معطل') return <X className="w-4 h-4" />;
    return <AlertCircle className="w-4 h-4" />;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4 md:p-8" dir="rtl">
      {/* Header */}
      <div className="mb-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-slate-900 flex items-center gap-3">
              <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center">
                <User className="w-6 h-6 text-white" />
              </div>
              إدارة المستخدمين
            </h1>
            <p className="text-slate-600 mt-2">إدارة حسابات المستخدمين والأدوار والصلاحيات</p>
          </div>
          <button
            onClick={handleAddUser}
            className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold flex items-center gap-2 transition-all duration-200 shadow-lg hover:shadow-xl"
          >
            <Plus className="w-5 h-5" />
            إضافة مستخدم جديد
          </button>
        </div>
      </div>

      {/* Filters Section */}
      <div className="bg-white rounded-xl shadow-sm p-6 mb-6 border border-slate-200">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* Search */}
          <div className="md:col-span-2">
            <label className="block text-sm font-semibold text-slate-700 mb-2">البحث</label>
            <div className="relative">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input
                type="text"
                placeholder="ابحث باسم أو بريد إلكتروني..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pr-10 pl-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>

          {/* Role Filter */}
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">الدور</label>
            <select
              value={filterRole}
              onChange={(e) => setFilterRole(e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none cursor-pointer"
            >
              <option>الكل</option>
              {roles.map(role => <option key={role}>{role}</option>)}
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-2">الحالة</label>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none cursor-pointer"
            >
              <option>الكل</option>
              {statuses.map(status => <option key={status}>{status}</option>)}
            </select>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-white rounded-lg p-4 shadow-sm border border-slate-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-600 text-sm font-medium">إجمالي المستخدمين</p>
              <p className="text-2xl font-bold text-slate-900 mt-1">{users.length}</p>
            </div>
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <User className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg p-4 shadow-sm border border-slate-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-600 text-sm font-medium">مستخدمون نشطون</p>
              <p className="text-2xl font-bold text-green-600 mt-1">{users.filter(u => u.status === 'نشط').length}</p>
            </div>
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <Check className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg p-4 shadow-sm border border-slate-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-600 text-sm font-medium">معطلون</p>
              <p className="text-2xl font-bold text-red-600 mt-1">{users.filter(u => u.status === 'معطل').length}</p>
            </div>
            <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
              <X className="w-6 h-6 text-red-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg p-4 shadow-sm border border-slate-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-slate-600 text-sm font-medium">أدوار مختلفة</p>
              <p className="text-2xl font-bold text-purple-600 mt-1">{new Set(users.map(u => u.role)).size}</p>
            </div>
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
              <Shield className="w-6 h-6 text-purple-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Users Table - Desktop */}
      <div className="hidden md:block bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gradient-to-r from-slate-50 to-slate-100 border-b border-slate-200">
                <th className="px-6 py-4 text-right text-sm font-semibold text-slate-700">المستخدم</th>
                <th className="px-6 py-4 text-right text-sm font-semibold text-slate-700">البريد الإلكتروني</th>
                <th className="px-6 py-4 text-right text-sm font-semibold text-slate-700">الهاتف</th>
                <th className="px-6 py-4 text-right text-sm font-semibold text-slate-700">الدور</th>
                <th className="px-6 py-4 text-right text-sm font-semibold text-slate-700">الحالة</th>
                <th className="px-6 py-4 text-right text-sm font-semibold text-slate-700">تاريخ الانضمام</th>
                <th className="px-6 py-4 text-center text-sm font-semibold text-slate-700">الإجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredUsers.map((user) => (
                <tr key={user.id} className="hover:bg-slate-50 transition-colors duration-150">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center text-white font-semibold">
                        {user.name.charAt(0)}
                      </div>
                      <span className="font-medium text-slate-900">{user.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-slate-600">{user.email}</td>
                  <td className="px-6 py-4 text-slate-600">{user.phone}</td>
                  <td className="px-6 py-4">
                    <span className="inline-flex items-center gap-2 px-3 py-1 bg-blue-50 text-blue-700 rounded-lg text-sm font-medium border border-blue-200">
                      <Shield className="w-4 h-4" />
                      {user.role}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center gap-2 px-3 py-1 rounded-lg text-sm font-medium ${getStatusColor(user.status)}`}>
                      {getStatusIcon(user.status)}
                      {user.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-slate-600 text-sm">{user.joinDate}</td>
                  <td className="px-6 py-4">
                    <div className="flex items-center justify-center gap-2">
                      <button
                        onClick={() => handleEditUser(user)}
                        className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors duration-150"
                        title="تعديل"
                      >
                        <Edit2 className="w-5 h-5" />
                      </button>
                      <button
                        onClick={() => setShowDeleteConfirm(user.id)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors duration-150"
                        title="حذف"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Users Cards - Mobile */}
      <div className="md:hidden grid grid-cols-1 gap-4">
        {filteredUsers.map((user) => (
          <div key={user.id} className="bg-white rounded-lg p-4 shadow-sm border border-slate-200">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center text-white font-semibold">
                  {user.name.charAt(0)}
                </div>
                <div>
                  <p className="font-semibold text-slate-900">{user.name}</p>
                  <p className="text-sm text-slate-600">{user.email}</p>
                </div>
              </div>
              <span className={`inline-flex items-center gap-1 px-2 py-1 rounded text-xs font-medium ${getStatusColor(user.status)}`}>
                {getStatusIcon(user.status)}
                {user.status}
              </span>
            </div>

            <div className="space-y-2 mb-4 text-sm">
              <div className="flex items-center gap-2 text-slate-600">
                <Phone className="w-4 h-4" />
                {user.phone}
              </div>
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-blue-600" />
                <span className="text-blue-600 font-medium">{user.role}</span>
              </div>
              <div className="flex items-center gap-2 text-slate-600">
                <Calendar className="w-4 h-4" />
                {user.joinDate}
              </div>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => handleEditUser(user)}
                className="flex-1 px-3 py-2 bg-blue-50 text-blue-600 rounded-lg font-medium hover:bg-blue-100 transition-colors duration-150 flex items-center justify-center gap-2"
              >
                <Edit2 className="w-4 h-4" />
                تعديل
              </button>
              <button
                onClick={() => setShowDeleteConfirm(user.id)}
                className="flex-1 px-3 py-2 bg-red-50 text-red-600 rounded-lg font-medium hover:bg-red-100 transition-colors duration-150 flex items-center justify-center gap-2"
              >
                <Trash2 className="w-4 h-4" />
                حذف
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Empty State */}
      {filteredUsers.length === 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-12 text-center">
          <User className="w-16 h-16 text-slate-300 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-slate-900 mb-2">لا توجد نتائج</h3>
          <p className="text-slate-600">حاول تغيير معايير البحث والفلترة</p>
        </div>
      )}

      {/* Edit/Add Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full max-h-screen overflow-y-auto">
            <div className="bg-gradient-to-r from-blue-600 to-blue-700 px-6 py-4 flex items-center justify-between">
              <h2 className="text-xl font-bold text-white">{editingUser ? 'تعديل المستخدم' : 'إضافة مستخدم جديد'}</h2>
              <button onClick={() => setShowModal(false)} className="text-white hover:bg-blue-800 p-1 rounded">
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">الاسم الكامل</label>
                <input type="text" placeholder="أدخل الاسم" className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" defaultValue={editingUser?.name} />
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">البريد الإلكتروني</label>
                <input type="email" placeholder="أدخل البريد الإلكتروني" className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" defaultValue={editingUser?.email} />
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">رقم الهاتف</label>
                <input type="tel" placeholder="أدخل رقم الهاتف" className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" defaultValue={editingUser?.phone} />
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">الدور</label>
                <select className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 appearance-none cursor-pointer" defaultValue={editingUser?.role}>
                  {roles.map(role => <option key={role}>{role}</option>)}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">الحالة</label>
                <select className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 appearance-none cursor-pointer" defaultValue={editingUser?.status}>
                  {statuses.map(status => <option key={status}>{status}</option>)}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-3">الصلاحيات</label>
                <div className="space-y-2">
                  {['قراءة', 'كتابة', 'حذف'].map(perm => (
                    <label key={perm} className="flex items-center gap-3 cursor-pointer">
                      <input type="checkbox" defaultChecked={editingUser?.permissions?.includes(perm)} className="w-4 h-4 text-blue-600 rounded cursor-pointer" />
                      <span className="text-slate-700">{perm}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button onClick={() => setShowModal(false)} className="flex-1 px-4 py-2 border border-slate-300 text-slate-700 rounded-lg font-medium hover:bg-slate-50">إلغاء</button>
                <button onClick={() => setShowModal(false)} className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700">{editingUser ? 'حفظ التغييرات' : 'إضافة المستخدم'}</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-2xl max-w-sm w-full p-6">
            <div className="flex items-center justify-center w-12 h-12 bg-red-100 rounded-full mx-auto mb-4">
              <AlertCircle className="w-6 h-6 text-red-600" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 text-center mb-2">حذف المستخدم</h3>
            <p className="text-slate-600 text-center mb-6">هل أنت متأكد من رغبتك في حذف هذا المستخدم؟ لا يمكن التراجع عن هذا الإجراء.</p>
            <div className="flex gap-3">
              <button onClick={() => setShowDeleteConfirm(null)} className="flex-1 px-4 py-2 border border-slate-300 text-slate-700 rounded-lg font-medium hover:bg-slate-50">إلغاء</button>
              <button onClick={() => handleDeleteUser(showDeleteConfirm)} className="flex-1 px-4 py-2 bg-red-600 text-white rounded-lg font-medium hover:bg-red-700">حذف</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
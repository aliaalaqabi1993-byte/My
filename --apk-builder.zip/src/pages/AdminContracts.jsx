┌───────────────────────────────────────────────────────────────┐
│            Header (top‑bar) – Logo | User Menu | Language    │
├───────────────────────────────────────────────────────────────┤
│ Sidebar (RTL) –  Admin, Contracts, Users, Settings, …        │
├───────────────────────────────────────────────────────────────┤
│ Main Content                                                    │
│  ├─ Toolbar: Search | Filters | Create | Export                │
│  ├─ Data Table (Contracts) – responsive, virtualized           │
│  │     · Column: ID, اسم العميل, براد، تاريخ البدء، حالة، …   │
│  │     · Actions: Edit, Delete, View Partners                  │
│  ├─ Drawer (Add/Edit Form) – responsive, slide‑from‑bottom    │
│  ├─ Popup: Confirm Delete / Error messages                    │
├───────────────────────────────────────────────────────────────┤
│            Footer (optional) – Version, Contacts              │
└───────────────────────────────────────────────────────────────┘

export default function AdminContracts() { return null; }
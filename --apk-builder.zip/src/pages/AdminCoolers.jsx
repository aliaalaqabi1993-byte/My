import React, { useState } from 'react';
import {
  Plus,
  Edit2,
  Trash2,
  Search,
  Filter,
  ChevronDown,
  AlertCircle,
  CheckCircle,
  XCircle,
  MapPin,
  Barcode,
  Settings,
  Eye,
  EyeOff,
} from 'lucide-react';

export default function CoolersManagement() {
  const [coolers, setCoolers] = useState([
    {
      id: 1,
      serialNumber: 'CL-2024-001',
      location: 'الفرع الرئيسي - قسم المبيعات',
      status: 'active',
      temperature: -18,
      capacity: 500,
      lastMaintenance: '2024-01-15',
      model: 'Premium Freezer X1',
    },
    {
      id: 2,
      serialNumber: 'CL-2024-002',
      location: 'الفرع الثانوي - المستودع',
      status: 'active',
      temperature: -20,
      capacity: 800,
      lastMaintenance: '2024-01-10',
      model: 'Industrial Cooler Pro',
    },
    {
      id: 3,
      serialNumber: 'CL-2024-003',
      location: 'فرع التوزيع - الشمال',
      status: 'warning',
      temperature: -15,
      capacity: 450,
      lastMaintenance: '2023-12-20',
      model: 'Standard Cooler Plus',
    },
    {
      id: 4,
      serialNumber: 'CL-2024-004',
      location: 'مركز التبريد الرئيسي',
      status: 'maintenance',
      temperature: 0,
      capacity: 1200,
      lastMaintenance: '2024-01-20',
      model: 'Commercial Unit 5000',
    },
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [formData, setFormData] = useState({
    serialNumber: '',
    location: '',
    status: 'active',
    model: '',
    capacity: '',
  });

  const getStatusConfig = (status) => {
    const configs = {
      active: { label: 'نشط', color: 'bg-green-50', textColor: 'text-green-700', borderColor: 'border-green-200', badge: 'bg-green-100 text-green-800', icon: CheckCircle },
      warning: { label: 'تحذير', color: 'bg-yellow-50', textColor: 'text-yellow-700', borderColor: 'border-yellow-200', badge: 'bg-yellow-100 text-yellow-800', icon: AlertCircle },
      maintenance: { label: 'صيانة', color: 'bg-blue-50', textColor: 'text-blue-700', borderColor: 'border-blue-200', badge: 'bg-blue-100 text-blue-800', icon: Settings },
      inactive: { label: 'معطل', color: 'bg-red-50', textColor: 'text-red-700', borderColor: 'border-red-200', badge: 'bg-red-100 text-red-800', icon: XCircle },
    };
    return configs[status] || configs.active;
  };

  const filteredCoolers = coolers.filter((cooler) => {
    const matchesSearch =
      cooler.serialNumber.includes(searchTerm) ||
      cooler.location.includes(searchTerm) ||
      cooler.model.includes(searchTerm);
    const matchesFilter = filterStatus === 'all' || cooler.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  const handleAddNew = () => {
    setEditingId(null);
    setFormData({ serialNumber: '', location: '', status: 'active', model: '', capacity: '' });
    setShowModal(true);
  };

  const handleEdit = (cooler) => {
    setEditingId(cooler.id);
    setFormData(cooler);
    setShowModal(true);
  };

  const handleSave = () => {
    if (editingId) {
      setCoolers(coolers.map((c) => (c.id === editingId ? { ...formData, id: editingId } : c)));
    } else {
      setCoolers([...coolers, { ...formData, id: Date.now() }]);
    }
    setShowModal(false);
  };

  const handleDelete = (id) => {
    if (confirm('هل أنت متأكد من حذف هذه البراد؟')) {
      setCoolers(coolers.filter((c) => c.id !== id));
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-slate-100" dir="rtl">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-400 rounded-lg flex items-center justify-center">
                  <Settings className="w-6 h-6 text-white" />
                </div>
                إدارة البرادات
              </h1>
              <p className="text-slate-600 text-sm mt-1">إدارة شاملة لجميع البرادات والثلاجات في الشركة</p>
            </div>
            <button
              onClick={handleAddNew}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 text-white font-semibold rounded-lg shadow-lg hover:shadow-xl transition-all duration-200 transform hover:scale-105"
            >
              <Plus className="w-5 h-5" />
              إضافة براد جديد
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search and Filter Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          {/* Search */}
          <div className="relative">
            <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              type="text"
              placeholder="ابحث برقم التسلسل أو الموقع أو الموديل..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pr-12 pl-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
            />
          </div>

          {/* Filter */}
          <div className="relative">
            <Filter className="absolute right-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="w-full pr-12 pl-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white appearance-none cursor-pointer"
            >
              <option value="all">جميع الحالات</option>
              <option value="active">نشط</option>
              <option value="warning">تحذير</option>
              <option value="maintenance">صيانة</option>
              <option value="inactive">معطل</option>
            </select>
            <ChevronDown className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400 pointer-events-none" />
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'إجمالي البرادات', value: coolers.length, color: 'from-blue-600 to-blue-400', icon: '📊' },
            { label: 'نشطة', value: coolers.filter((c) => c.status === 'active').length, color: 'from-green-600 to-green-400', icon: '✅' },
            { label: 'تحذيرات', value: coolers.filter((c) => c.status === 'warning').length, color: 'from-yellow-600 to-yellow-400', icon: '⚠️' },
            { label: 'صيانة', value: coolers.filter((c) => c.status === 'maintenance').length, color: 'from-purple-600 to-purple-400', icon: '🔧' },
          ].map((stat, idx) => (
            <div
              key={idx}
              className={`bg-gradient-to-br ${stat.color} rounded-lg p-6 text-white shadow-lg hover:shadow-xl transition-shadow`}
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium opacity-90">{stat.label}</p>
                  <p className="text-3xl font-bold mt-2">{stat.value}</p>
                </div>
                <span className="text-4xl opacity-50">{stat.icon}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Table */}
        <div className="bg-white rounded-lg shadow-lg overflow-hidden border border-slate-200">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gradient-to-r from-slate-900 to-slate-800">
                <tr>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-white">الرقم التسلسلي</th>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-white">الموديل</th>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-white">الموقع</th>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-white">درجة الحرارة</th>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-white">السعة</th>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-white">الحالة</th>
                  <th className="px-6 py-4 text-right text-sm font-semibold text-white">الإجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {filteredCoolers.length > 0 ? (
                  filteredCoolers.map((cooler) => {
                    const statusConfig = getStatusConfig(cooler.status);
                    const StatusIcon = statusConfig.icon;
                    return (
                      <tr key={cooler.id} className="hover:bg-slate-50 transition-colors">
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2">
                            <Barcode className="w-4 h-4 text-blue-600" />
                            <span className="font-mono font-semibold text-slate-900">{cooler.serialNumber}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-slate-700 font-medium">{cooler.model}</span>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2 text-slate-700">
                            <MapPin className="w-4 h-4 text-slate-400" />
                            <span className="text-sm">{cooler.location}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-1 bg-blue-50 px-3 py-2 rounded-lg w-fit">
                            <span className="font-semibold text-blue-700">{cooler.temperature}°C</span>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-slate-700 font-medium">{cooler.capacity} لتر</span>
                        </td>
                        <td className="px-6 py-4">
                          <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full ${statusConfig.badge}`}>
                            <StatusIcon className="w-4 h-4" />
                            <span className="text-xs font-semibold">{statusConfig.label}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => handleEdit(cooler)}
                              className="p-2 hover:bg-blue-50 rounded-lg text-blue-600 hover:text-blue-700 transition-colors"
                              title="تعديل"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleDelete(cooler.id)}
                              className="p-2 hover:bg-red-50 rounded-lg text-red-600 hover:text-red-700 transition-colors"
                              title="حذف"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan="7" className="px-6 py-12 text-center text-slate-500">
                      <AlertCircle className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                      <p className="font-medium">لا توجد نتائج مطابقة</p>
                      <p className="text-sm">حاول تغيير معايير البحث أو الفلترة</p>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-blue-600 to-blue-500 px-6 py-6 text-white">
              <h2 className="text-xl font-bold">{editingId ? 'تعديل براد' : 'إضافة براد جديد'}</h2>
              <p className="text-blue-100 text-sm mt-1">أدخل البيانات المطلوبة</p>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">الرقم التسلسلي</label>
                <input
                  type="text"
                  value={formData.serialNumber}
                  onChange={(e) => setFormData({ ...formData, serialNumber: e.target.value })}
                  placeholder="مثال: CL-2024-001"
                  className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">الموديل</label>
                <input
                  type="text"
                  value={formData.model}
                  onChange={(e) => setFormData({ ...formData, model: e.target.value })}
                  placeholder="مثال: Premium Freezer X1"
                  className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">الموقع</label>
                <input
                  type="text"
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  placeholder="مثال: الفرع الرئيسي - قسم المبيعات"
                  className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">السعة (لتر)</label>
                <input
                  type="number"
                  value={formData.capacity}
                  onChange={(e) => setFormData({ ...formData, capacity: e.target.value })}
                  placeholder="مثال: 500"
                  className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">الحالة</label>
                <select
                  value={formData.status}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 appearance-none bg-white"
                >
                  <option value="active">نشط</option>
                  <option value="warning">تحذير</option>
                  <option value="maintenance">صيانة</option>
                  <option value="inactive">معطل</option>
                </select>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="border-t border-slate-200 px-6 py-4 flex gap-3 justify-end bg-slate-50">
              <button
                onClick={() => setShowModal(false)}
                className="px-4 py-2 border border-slate-200 text-slate-700 font-medium rounded-lg hover:bg-slate-100 transition-colors"
              >
                إلغاء
              </button>
              <button
                onClick={handleSave}
                className="px-4 py-2 bg-gradient-to-r from-blue-600 to-blue-500 text-white font-medium rounded-lg hover:from-blue-700 hover:to-blue-600 transition-colors"
              >
                {editingId ? 'تحديث' : 'إضافة'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
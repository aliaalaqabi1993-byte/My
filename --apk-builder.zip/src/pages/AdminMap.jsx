'use client';

import React, { useState, useEffect } from 'react';
import { MapPin, AlertCircle, CheckCircle, TrendingUp, Filter, Search, Eye, EyeOff } from 'lucide-react';

export default function CoolersMap() {
  const [selectedCooler, setSelectedCooler] = useState(null);
  const [filterStatus, setFilterStatus] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [coolers, setCoolers] = useState([
    { id: 1, name: 'براد الرياض - الشرقية', lat: 24.7136, lng: 46.6753, status: 'active', temp: 4.2, capacity: 85, lastMaintenance: '2024-01-15', region: 'الرياض' },
    { id: 2, name: 'براد جدة - الميناء', lat: 21.5433, lng: 39.1728, status: 'active', temp: 3.8, capacity: 92, lastMaintenance: '2024-01-18', region: 'جدة' },
    { id: 3, name: 'براد الدمام - المركز', lat: 26.3954, lng: 50.1957, status: 'warning', temp: 8.5, capacity: 65, lastMaintenance: '2023-12-20', region: 'الدمام' },
    { id: 4, name: 'براد الخبر - الشمالية', lat: 26.1547, lng: 50.2055, status: 'active', temp: 4.0, capacity: 78, lastMaintenance: '2024-01-10', region: 'الخبر' },
    { id: 5, name: 'براد مكة - الحرم', lat: 21.4225, lng: 39.8262, status: 'inactive', temp: 15.2, capacity: 0, lastMaintenance: '2023-11-05', region: 'مكة' },
    { id: 6, name: 'براد المدينة - المركز', lat: 24.4672, lng: 39.6028, status: 'active', temp: 3.5, capacity: 88, lastMaintenance: '2024-01-17', region: 'المدينة' },
    { id: 7, name: 'براد القصيم - الرياض', lat: 26.1267, lng: 46.7219, status: 'active', temp: 4.3, capacity: 81, lastMaintenance: '2024-01-12', region: 'القصيم' },
    { id: 8, name: 'براد تبوك - الشرقية', lat: 28.3896, lng: 36.5624, status: 'warning', temp: 9.1, capacity: 42, lastMaintenance: '2023-12-28', region: 'تبوك' },
  ]);

  const getStatusColor = (status) => {
    switch(status) {
      case 'active': return { bg: 'bg-emerald-50', border: 'border-emerald-200', text: 'text-emerald-700', badge: 'bg-emerald-100' };
      case 'warning': return { bg: 'bg-amber-50', border: 'border-amber-200', text: 'text-amber-700', badge: 'bg-amber-100' };
      case 'inactive': return { bg: 'bg-red-50', border: 'border-red-200', text: 'text-red-700', badge: 'bg-red-100' };
      default: return { bg: 'bg-gray-50', border: 'border-gray-200', text: 'text-gray-700', badge: 'bg-gray-100' };
    }
  };

  const getStatusLabel = (status) => {
    switch(status) {
      case 'active': return 'نشط';
      case 'warning': return 'تحذير';
      case 'inactive': return 'معطل';
      default: return 'غير معروف';
    }
  };

  const getStatusIcon = (status) => {
    switch(status) {
      case 'active': return <CheckCircle className="w-4 h-4 text-emerald-600" />;
      case 'warning': return <AlertCircle className="w-4 h-4 text-amber-600" />;
      case 'inactive': return <AlertCircle className="w-4 h-4 text-red-600" />;
      default: return <MapPin className="w-4 h-4 text-gray-600" />;
    }
  };

  const filteredCoolers = coolers.filter(cooler => {
    const matchesStatus = filterStatus === 'all' || cooler.status === filterStatus;
    const matchesSearch = cooler.name.includes(searchQuery) || cooler.region.includes(searchQuery);
    return matchesStatus && matchesSearch;
  });

  const stats = {
    total: coolers.length,
    active: coolers.filter(c => c.status === 'active').length,
    warning: coolers.filter(c => c.status === 'warning').length,
    inactive: coolers.filter(c => c.status === 'inactive').length,
    avgCapacity: Math.round(coolers.reduce((sum, c) => sum + c.capacity, 0) / coolers.length),
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50" dir="rtl">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
                <MapPin className="w-8 h-8" style={{ color: '#1976D2' }} />
                خريطة توزيع البرادات
              </h1>
              <p className="text-gray-600 text-sm mt-1">مراقبة توزيع وحالة جميع البرادات عبر المملكة</p>
            </div>
            <button 
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <Filter className="w-4 h-4" />
              <span>التصفية</span>
            </button>
          </div>
        </div>
      </div>

      {/* Stats Bar */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-3 border border-blue-200">
              <p className="text-gray-600 text-xs font-medium">إجمالي البرادات</p>
              <p className="text-2xl font-bold text-blue-900 mt-1">{stats.total}</p>
            </div>
            <div className="bg-gradient-to-br from-emerald-50 to-emerald-100 rounded-lg p-3 border border-emerald-200">
              <p className="text-gray-600 text-xs font-medium">نشطة</p>
              <p className="text-2xl font-bold text-emerald-700 mt-1">{stats.active}</p>
            </div>
            <div className="bg-gradient-to-br from-amber-50 to-amber-100 rounded-lg p-3 border border-amber-200">
              <p className="text-gray-600 text-xs font-medium">تحذير</p>
              <p className="text-2xl font-bold text-amber-700 mt-1">{stats.warning}</p>
            </div>
            <div className="bg-gradient-to-br from-red-50 to-red-100 rounded-lg p-3 border border-red-200">
              <p className="text-gray-600 text-xs font-medium">معطلة</p>
              <p className="text-2xl font-bold text-red-700 mt-1">{stats.inactive}</p>
            </div>
            <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg p-3 border border-purple-200">
              <p className="text-gray-600 text-xs font-medium">متوسط السعة</p>
              <p className="text-2xl font-bold text-purple-700 mt-1">{stats.avgCapacity}%</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      {showFilters && (
        <div className="bg-white border-b border-gray-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">البحث</label>
                <div className="relative">
                  <Search className="absolute right-3 top-3 w-4 h-4 text-gray-400" />
                  <input
                    type="text"
                    placeholder="ابحث بالاسم أو المنطقة..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pr-10 pl-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">الحالة</label>
                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="all">جميع الحالات</option>
                  <option value="active">نشطة</option>
                  <option value="warning">تحذير</option>
                  <option value="inactive">معطلة</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Map Area */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden h-[600px] relative">
              {/* Simulated Map */}
              <div className="w-full h-full bg-gradient-to-br from-blue-100 to-blue-50 relative overflow-hidden">
                {/* Grid Background */}
                <div className="absolute inset-0 opacity-10">
                  <svg width="100%" height="100%">
                    <defs>
                      <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                        <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#1976D2" strokeWidth="0.5"/>
                      </pattern>
                    </defs>
                    <rect width="100%" height="100%" fill="url(#grid)" />
                  </svg>
                </div>

                {/* Cooler Markers */}
                <div className="absolute inset-0">
                  {filteredCoolers.map((cooler, index) => {
                    const x = 15 + (cooler.lng - 36) * 2 + (index % 3) * 8;
                    const y = 25 + (cooler.lat - 21) * 1.5 + Math.floor(index / 3) * 8;
                    const colors = getStatusColor(cooler.status);
                    
                    return (
                      <div
                        key={cooler.id}
                        className="absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer group"
                        style={{
                          left: `${Math.min(Math.max(x, 5), 95))}%`,
                          top: `${Math.min(Math.max(y, 5), 95))}%`,
                        }}
                        onClick={() => setSelectedCooler(cooler)}
                      >
                        {/* Pulse Ring */}
                        {cooler.status === 'active' && (
                          <div className="absolute inset-0 w-8 h-8 rounded-full border-2 border-emerald-400 opacity-0 group-hover:opacity-100 animate-ping" />
                        )}
                        
                        {/* Marker */}
                        <div className={`w-8 h-8 rounded-full border-2 flex items-center justify-center transition-all transform group-hover:scale-125 ${colors.bg} ${colors.border} ${selectedCooler?.id === cooler.id ? 'ring-4 ring-offset-2 ring-blue-400 scale-125' : ''}`}>
                          {getStatusIcon(cooler.status)}
                        </div>

                        {/* Tooltip */}
                        <div className="absolute bottom-full right-0 mb-2 bg-gray-900 text-white px-3 py-2 rounded-lg text-xs whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10">
                          {cooler.name}
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Map Legend */}
                <div className="absolute bottom-4 left-4 bg-white rounded-lg shadow-lg p-3 border border-gray-200">
                  <p className="text-xs font-semibold text-gray-700 mb-2">وسيلة الإيضاح</p>
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-3 h-3 text-emerald-600" />
                      <span className="text-xs text-gray-600">نشط</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <AlertCircle className="w-3 h-3 text-amber-600" />
                      <span className="text-xs text-gray-600">تحذير</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <AlertCircle className="w-3 h-3 text-red-600" />
                      <span className="text-xs text-gray-600">معطل</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar - Details Panel */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden sticky top-32">
              {selectedCooler ? (
                <div className="h-[600px] overflow-y-auto">
                  {/* Header */}
                  <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h2 className="text-lg font-bold">{selectedCooler.name}</h2>
                        <p className="text-blue-100 text-sm mt-1">{selectedCooler.region}</p>
                      </div>
                      <button
                        onClick={() => setSelectedCooler(null)}
                        className="text-white hover:bg-blue-600 rounded-lg p-1 transition-colors"
                      >
                        <EyeOff className="w-4 h-4" />
                      </button>
                    </div>
                    <div className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold ${getStatusColor(selectedCooler.status).badge}`}>
                      {getStatusIcon(selectedCooler.status)}
                      <span className={getStatusColor(selectedCooler.status).text}>{getStatusLabel(selectedCooler.status)}</span>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-4 space-y-4">
                    {/* Temperature */}
                    <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-4 border border-blue-200">
                      <p className="text-gray-600 text-xs font-medium mb-1">درجة الحرارة</p>
                      <p className="text-3xl font-bold text-blue-900">{selectedCooler.temp}°C</p>
                      <p className="text-xs text-blue-700 mt-1">نطاق آمن: 2-6°C</p>
                    </div>

                    {/* Capacity */}
                    <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg p-4 border border-purple-200">
                      <p className="text-gray-600 text-xs font-medium mb-2">سعة التخزين</p>
                      <div className="w-full bg-purple-200 rounded-full h-2 overflow-hidden">
                        <div
                          className="bg-gradient-to-r from-purple-500 to-purple-600 h-full transition-all duration-300"
                          style={{ width: `${selectedCooler.capacity}%` }}
                        />
                      </div>
                      <p className="text-sm font-bold text-purple-900 mt-2">{selectedCooler.capacity}%</p>
                    </div>

                    {/* Coordinates */}
                    <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                      <p className="text-gray-600 text-xs font-medium mb-2">الإحداثيات</p>
                      <div className="text-sm text-gray-700 space-y-1">
                        <p>خط العرض: <span className="font-mono font-semibold text-gray-900">{selectedCooler.lat.toFixed(4)}°</span></p>
                        <p>خط الطول: <span className="font-mono font-semibold text-gray-900">{selectedCooler.lng.toFixed(4)}°</span></p>
                      </div>
                    </div>

                    {/* Last Maintenance */}
                    <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                      <p className="text-gray-600 text-xs font-medium mb-2">آخر صيانة</p>
                      <p className="text-sm font-semibold text-gray-900">{new Date(selectedCooler.lastMaintenance).toLocaleDateString('ar-SA')}</p>
                      <p className="text-xs text-gray-500 mt-1">
                        منذ {Math.floor((Date.now() - new Date(selectedCooler.lastMaintenance).getTime()) / (1000 * 60 * 60 * 24))} يوم
                      </p>
                    </div>

                    {/* ID */}
                    <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                      <p className="text-gray-600 text-xs font-medium mb-2">معرّف البراد</p>
                      <p className="text-sm font-mono font-semibold text-gray-900">COOLER-{String(selectedCooler.id).padStart(4, '0')}</p>
                    </div>

                    {/* Actions */}
                    <div className="pt-2 space-y-2">
                      <button className="w-full px-4 py-2 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-lg hover:from-blue-700 hover:to-blue-800 transition-all font-medium text-sm">
                        عرض التفاصيل
                      </button>
                      <button className="w-full px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors font-medium text-sm">
                        جدول الصيانة
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="h-[600px] flex flex-col items-center justify-center text-center p-6">
                  <div className="bg-blue-100 rounded-full p-4 mb-3">
                    <MapPin className="w-8 h-8 text-blue-600" />
                  </div>
                  <p className="text-gray-700 font-semibold mb-1">اختر براداً على الخريطة</p>
                  <p className="text-gray-500 text-sm">انقر على أي علامة على الخريطة لعرض التفاصيل الكاملة والمراقبة المباشرة</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Coolers List */}
        <div className="mt-8 bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
            <h3 className="text-lg font-bold text-gray-900">قائمة البرادات ({filteredCoolers.length})</h3>
            <TrendingUp className="w-5 h-5 text-blue-600" />
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-3 text-right text-xs font-semibold text-gray-700">الاسم</th>
                  <th className="px-6 py-3 text-right text-xs font-semibold text-gray-700">المنطقة</th>
                  <th className="px-6 py-3 text-right text-xs font-semibold text-gray-700">الحالة</th>
                  <th className="px-6 py-3 text-right text-xs font-semibold text-gray-700">درجة الحرارة</th>
                  <th className="px-6 py-3 text-right text-xs font-semibold text-gray-700">السعة</th>
                  <th className="px-6 py-3 text-right text-xs font-semibold text-gray-700">آخر صيانة</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredCoolers.map((cooler) => {
                  const colors = getStatusColor(cooler.status);
                  return (
                    <tr
                      key={cooler.id}
                      onClick={() => setSelectedCooler(cooler)}
                      className="hover:bg-blue-50 transition-colors cursor-pointer"
                    >
                      <td className="px-6 py-4 text-sm font-medium text-gray-900">{cooler.name}</td>
                      <td className="px-6 py-4 text-sm text-gray-600">{cooler.region}</td>
                      <td className="px-6 py-4 text-sm">
                        <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold ${colors.badge}`}>
                          {getStatusIcon(cooler.status)}
                          <span className={colors.text}>{getStatusLabel(cooler.status)}</span>
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm font-semibold text-gray-900">{cooler.temp}°C</td>
                      <td className="px-6 py-4 text-sm">
                        <div className="flex items-center gap-2">
                          <div className="w-16 bg-gray-200 rounded-full h-1.5 overflow-hidden">
                            <div
                              className="bg-gradient-to-r from-blue-500 to-blue-600 h-full"
                              style={{ width: `${cooler.capacity}%` }}
                            />
                          </div>
                          <span className="font-semibold text-gray-700 text-xs w-8">{cooler.capacity}%</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-600">{new Date(cooler.lastMaintenance).toLocaleDateString('ar-SA')}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
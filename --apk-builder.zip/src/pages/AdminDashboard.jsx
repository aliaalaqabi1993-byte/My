export default function AdminDashboard() {
  const stats = [
    { label: 'إجمالي البراد', value: '1,245', icon: '❄️', color: 'bg-blue-50', textColor: 'text-blue-600', borderColor: 'border-blue-200' },
    { label: 'العقود النشطة', value: '89', icon: '📋', color: 'bg-green-50', textColor: 'text-green-600', borderColor: 'border-green-200' },
    { label: 'الأعطال المسجلة', value: '12', icon: '⚠️', color: 'bg-red-50', textColor: 'text-red-600', borderColor: 'border-red-200' },
    { label: 'معدل الكفاءة', value: '94.5%', icon: '📊', color: 'bg-purple-50', textColor: 'text-purple-600', borderColor: 'border-purple-200' }
  ];

  const recentFaults = [
    { id: 1, unit: 'وحدة التبريد #A-001', type: 'عطل كهربائي', date: '2024-01-15', status: 'قيد الإصلاح', priority: 'عالي' },
    { id: 2, unit: 'وحدة التبريد #B-045', type: 'تسريب الفريون', date: '2024-01-14', status: 'مكتمل', priority: 'متوسط' },
    { id: 3, unit: 'وحدة التبريد #C-078', type: 'عطل في الضاغط', date: '2024-01-13', status: 'قيد الانتظار', priority: 'عالي' },
    { id: 4, unit: 'وحدة التبريد #D-012', type: 'صيانة دورية', date: '2024-01-12', status: 'مكتمل', priority: 'منخفض' },
    { id: 5, unit: 'وحدة التبريد #E-089', type: 'ارتفاع درجة الحرارة', date: '2024-01-11', status: 'قيد الإصلاح', priority: 'عالي' }
  ];

  const contracts = [
    { id: 1, name: 'عقد الصيانة السنوية - المنطقة الشمالية', value: '45,000 ر.س', expiry: '2024-12-31', status: 'نشط' },
    { id: 2, name: 'خدمة الدعم الفني 24/7', value: '28,500 ر.س', expiry: '2024-06-30', status: 'نشط' },
    { id: 3, name: 'عقد التجديد والاستبدال', value: '62,000 ر.س', expiry: '2024-03-15', status: 'قريب الانتهاء' }
  ];

  const getStatusColor = (status) => {
    switch(status) {
      case 'قيد الإصلاح': return 'bg-orange-100 text-orange-800';
      case 'مكتمل': return 'bg-green-100 text-green-800';
      case 'قيد الانتظار': return 'bg-yellow-100 text-yellow-800';
      case 'نشط': return 'bg-blue-100 text-blue-800';
      case 'قريب الانتهاء': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityColor = (priority) => {
    switch(priority) {
      case 'عالي': return 'text-red-600';
      case 'متوسط': return 'text-orange-600';
      case 'منخفض': return 'text-green-600';
      default: return 'text-gray-600';
    }
  };

  return (
    <div dir="rtl" className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4 md:p-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-2">لوحة التحكم</h1>
        <p className="text-lg text-slate-600">مرحباً بك في نظام إدارة البراد الذكي</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => (
          <div key={index} className={`${stat.color} border-r-4 ${stat.borderColor} rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow duration-300`}>
            <div className="flex items-center justify-between mb-4">
              <span className="text-4xl">{stat.icon}</span>
              <span className={`text-3xl font-bold ${stat.textColor}`}>{stat.value}</span>
            </div>
            <p className="text-slate-700 font-semibold">{stat.label}</p>
            <div className="mt-3 h-1 bg-gradient-to-l from-slate-300 to-transparent rounded-full"></div>
          </div>
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Faults - Takes 2 columns on large screens */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            <div className="bg-gradient-to-r from-red-600 to-red-700 px-6 py-4">
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                <span>⚠️</span> الأعطال المسجلة
              </h2>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-slate-100 border-b border-slate-200">
                    <th className="px-6 py-4 text-right text-sm font-semibold text-slate-700">الوحدة</th>
                    <th className="px-6 py-4 text-right text-sm font-semibold text-slate-700">نوع العطل</th>
                    <th className="px-6 py-4 text-right text-sm font-semibold text-slate-700">التاريخ</th>
                    <th className="px-6 py-4 text-right text-sm font-semibold text-slate-700">الحالة</th>
                    <th className="px-6 py-4 text-right text-sm font-semibold text-slate-700">الأولوية</th>
                  </tr>
                </thead>
                <tbody>
                  {recentFaults.map((fault) => (
                    <tr key={fault.id} className="border-b border-slate-200 hover:bg-slate-50 transition-colors">
                      <td className="px-6 py-4 text-sm text-slate-900 font-medium">{fault.unit}</td>
                      <td className="px-6 py-4 text-sm text-slate-600">{fault.type}</td>
                      <td className="px-6 py-4 text-sm text-slate-600">{fault.date}</td>
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${getStatusColor(fault.status)}`}>
                          {fault.status}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`text-sm font-bold ${getPriorityColor(fault.priority)}`}>
                          {fault.priority}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="px-6 py-4 bg-slate-50 border-t border-slate-200">
              <button className="text-blue-600 hover:text-blue-700 font-semibold text-sm transition-colors">
                عرض جميع الأعطال →
              </button>
            </div>
          </div>
        </div>

        {/* Contracts Sidebar */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="bg-gradient-to-r from-blue-600 to-blue-700 px-6 py-4">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <span>📋</span> العقود
            </h2>
          </div>
          <div className="p-6 space-y-4">
            {contracts.map((contract) => (
              <div key={contract.id} className="p-4 bg-gradient-to-br from-slate-50 to-slate-100 rounded-lg border border-slate-200 hover:border-blue-300 transition-all">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-semibold text-slate-900 text-sm leading-snug">{contract.name}</h3>
                  <span className={`px-2 py-1 rounded text-xs font-bold whitespace-nowrap ml-2 ${
                    contract.status === 'نشط' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                  }`}>
                    {contract.status}
                  </span>
                </div>
                <div className="space-y-1 text-xs text-slate-600">
                  <p><span className="font-semibold text-slate-700">القيمة:</span> {contract.value}</p>
                  <p><span className="font-semibold text-slate-700">الانتهاء:</span> {contract.expiry}</p>
                </div>
              </div>
            ))}
            <button className="w-full mt-4 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors">
              إضافة عقد جديد
            </button>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="mt-8 bg-white rounded-xl shadow-lg p-6">
        <h2 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-2">
          <span>⚡</span> الإجراءات السريعة
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <button className="bg-gradient-to-br from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-semibold py-3 px-4 rounded-lg transition-all transform hover:scale-105 shadow-md">
            📊 إنشاء تقرير جديد
          </button>
          <button className="bg-gradient-to-br from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-semibold py-3 px-4 rounded-lg transition-all transform hover:scale-105 shadow-md">
            ✅ إضافة وحدة جديدة
          </button>
          <button className="bg-gradient-to-br from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-semibold py-3 px-4 rounded-lg transition-all transform hover:scale-105 shadow-md">
            🔧 جدولة الصيانة
          </button>
          <button className="bg-gradient-to-br from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white font-semibold py-3 px-4 rounded-lg transition-all transform hover:scale-105 shadow-md">
            📈 عرض الإحصائيات
          </button>
        </div>
      </div>

      {/* Footer Stats */}
      <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-xl p-6 text-white shadow-lg">
          <p className="text-sm font-semibold opacity-90">معدل التوفر</p>
          <p className="text-4xl font-bold mt-2">98.7%</p>
          <p className="text-xs opacity-75 mt-2">↑ زيادة 2.3% من الشهر الماضي</p>
        </div>
        <div className="bg-gradient-to-br from-cyan-500 to-cyan-600 rounded-xl p-6 text-white shadow-lg">
          <p className="text-sm font-semibold opacity-90">متوسط وقت الإصلاح</p>
          <p className="text-4xl font-bold mt-2">4.2 ساعة</p>
          <p className="text-xs opacity-75 mt-2">↓ تحسن 0.8 ساعة</p>
        </div>
        <div className="bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-xl p-6 text-white shadow-lg">
          <p className="text-sm font-semibold opacity-90">رضا العملاء</p>
          <p className="text-4xl font-bold mt-2">4.8/5</p>
          <p className="text-xs opacity-75 mt-2">من 156 تقييم</p>
        </div>
      </div>
    </div>
  );
}
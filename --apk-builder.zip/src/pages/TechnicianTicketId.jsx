import React, { useState } from 'react';
import { MapPin, Clock, AlertCircle, CheckCircle2, Phone, MessageSquare, User, Calendar, Zap } from 'lucide-react';

export default function TicketDetails() {
  const [status, setStatus] = useState('in-progress');
  const [showResolveModal, setShowResolveModal] = useState(false);
  const [resolutionNote, setResolutionNote] = useState('');

  const ticket = {
    id: 'TK-2024-001847',
    title: 'عطل في نظام التكييف - الوحدة الخارجية',
    description: 'المكيف لا يبرد بشكل صحيح، الوحدة الخارجية تصدر أصواتاً غريبة',
    location: 'الدور الثاني - غرفة المدير العام',
    address: 'مبنى المركز الرئيسي، شارع النيل، القاهرة',
    priority: 'high',
    createdAt: '2024-01-15 09:30',
    estimatedTime: '2-3 ساعات',
    category: 'تكييف الهواء',
    customer: {
      name: 'أحمد محمد علي',
      phone: '+20 100 123 4567',
      email: 'ahmed@company.com'
    },
    technician: {
      name: 'خالد إبراهيم',
      rating: 4.8,
      phone: '+20 101 987 6543'
    },
    checklist: [
      { id: 1, task: 'فحص الوحدة الخارجية', completed: true },
      { id: 2, task: 'قياس ضغط الفريون', completed: true },
      { id: 3, task: 'تنظيف المرشحات', completed: true },
      { id: 4, task: 'اختبار الأداء', completed: false }
    ]
  };

  const handleResolve = () => {
    setStatus('resolved');
    setShowResolveModal(false);
  };

  return (
    <div dir="rtl" className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-sm">
        <div className="px-4 py-4 sm:px-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-slate-900">{ticket.id}</h1>
              <p className="text-sm text-slate-600 mt-1">{ticket.title}</p>
            </div>
            <div className={`px-3 py-1 rounded-full text-sm font-semibold ${
              status === 'resolved' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'
            }`}>
              {status === 'resolved' ? '✓ تم الإصلاح' : '⏳ جاري العمل'}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="px-4 py-6 sm:px-6 space-y-6">
        
        {/* Alert Banner */}
        {ticket.priority === 'high' && (
          <div className="flex items-start gap-3 p-4 bg-red-50 border border-red-200 rounded-lg">
            <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-red-900">أولوية عالية</p>
              <p className="text-sm text-red-800">هذا العطل يحتاج إلى معالجة سريعة</p>
            </div>
          </div>
        )}

        {/* Ticket Info Card */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="bg-gradient-to-r from-blue-600 to-blue-700 px-6 py-4">
            <p className="text-white font-semibold text-lg">{ticket.category}</p>
          </div>
          <div className="p-6 space-y-4">
            <div className="flex items-start gap-3">
              <MapPin className="w-5 h-5 text-blue-600 flex-shrink-0 mt-1" />
              <div>
                <p className="font-semibold text-slate-900">{ticket.location}</p>
                <p className="text-sm text-slate-600 mt-1">{ticket.address}</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Zap className="w-5 h-5 text-blue-600 flex-shrink-0 mt-1" />
              <div>
                <p className="font-semibold text-slate-900">وصف العطل</p>
                <p className="text-sm text-slate-600 mt-1">{ticket.description}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Timeline Info */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white rounded-lg p-4 border border-slate-200">
            <div className="flex items-center gap-2 mb-2">
              <Calendar className="w-4 h-4 text-slate-600" />
              <p className="text-xs font-semibold text-slate-600 uppercase">تاريخ الإنشاء</p>
            </div>
            <p className="text-sm font-semibold text-slate-900">{ticket.createdAt}</p>
          </div>
          <div className="bg-white rounded-lg p-4 border border-slate-200">
            <div className="flex items-center gap-2 mb-2">
              <Clock className="w-4 h-4 text-slate-600" />
              <p className="text-xs font-semibold text-slate-600 uppercase">الوقت المتوقع</p>
            </div>
            <p className="text-sm font-semibold text-slate-900">{ticket.estimatedTime}</p>
          </div>
        </div>

        {/* Customer Info */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h3 className="font-bold text-slate-900 mb-4 flex items-center gap-2">
            <User className="w-5 h-5 text-blue-600" />
            معلومات العميل
          </h3>
          <div className="space-y-3">
            <div>
              <p className="text-xs text-slate-600 font-semibold uppercase">الاسم</p>
              <p className="text-sm font-semibold text-slate-900 mt-1">{ticket.customer.name}</p>
            </div>
            <div className="flex gap-2">
              <a href={`tel:${ticket.customer.phone}`} className="flex-1 flex items-center justify-center gap-2 bg-blue-50 hover:bg-blue-100 text-blue-700 font-semibold py-3 rounded-lg transition">
                <Phone className="w-4 h-4" />
                اتصال
              </a>
              <a href={`mailto:${ticket.customer.email}`} className="flex-1 flex items-center justify-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold py-3 rounded-lg transition">
                <MessageSquare className="w-4 h-4" />
                رسالة
              </a>
            </div>
          </div>
        </div>

        {/* Technician Info */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h3 className="font-bold text-slate-900 mb-4 flex items-center gap-2">
            <User className="w-5 h-5 text-green-600" />
            الفني المسؤول
          </h3>
          <div className="space-y-3">
            <div>
              <p className="text-xs text-slate-600 font-semibold uppercase">الاسم</p>
              <p className="text-sm font-semibold text-slate-900 mt-1">{ticket.technician.name}</p>
            </div>
            <div>
              <p className="text-xs text-slate-600 font-semibold uppercase">التقييم</p>
              <div className="flex items-center gap-1 mt-1">
                <span className="text-yellow-400">★★★★★</span>
                <span className="text-sm font-semibold text-slate-900">{ticket.technician.rating}</span>
              </div>
            </div>
            <a href={`tel:${ticket.technician.phone}`} className="w-full flex items-center justify-center gap-2 bg-green-50 hover:bg-green-100 text-green-700 font-semibold py-3 rounded-lg transition">
              <Phone className="w-4 h-4" />
              اتصل بالفني
            </a>
          </div>
        </div>

        {/* Checklist */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h3 className="font-bold text-slate-900 mb-4 flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-blue-600" />
            قائمة المهام
          </h3>
          <div className="space-y-3">
            {ticket.checklist.map((item) => (
              <div key={item.id} className={`flex items-center gap-3 p-3 rounded-lg ${
                item.completed ? 'bg-green-50' : 'bg-slate-50'
              }`}>
                <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 ${
                  item.completed ? 'bg-green-500' : 'bg-slate-300'
                }`}>
                  {item.completed && <span className="text-white text-sm">✓</span>}
                </div>
                <span className={`text-sm font-medium ${
                  item.completed ? 'text-green-700' : 'text-slate-700'
                }`}>
                  {item.task}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3 pb-6">
          {status !== 'resolved' ? (
            <>
              <button
                onClick={() => setShowResolveModal(true)}
                className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-bold py-4 rounded-lg transition shadow-md"
              >
                ✓ تم الإصلاح
              </button>
              <button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-lg transition">
                إضافة ملاحظة
              </button>
            </>
          ) : (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-center">
              <p className="font-semibold text-green-900">✓ تم إصلاح العطل بنجاح</p>
            </div>
          )}
        </div>
      </div>

      {/* Resolve Modal */}
      {showResolveModal && (
        <div className="fixed inset-0 bg-black/50 flex items-end z-50">
          <div className="w-full bg-white rounded-t-2xl p-6 animate-in slide-in-from-bottom-5">
            <h3 className="text-lg font-bold text-slate-900 mb-4">تأكيد إصلاح العطل</h3>
            <textarea
              value={resolutionNote}
              onChange={(e) => setResolutionNote(e.target.value)}
              placeholder="أضف ملاحظة عن العمل المنجز..."
              className="w-full border border-slate-300 rounded-lg p-3 text-sm mb-4 focus:outline-none focus:ring-2 focus:ring-blue-500"
              rows="4"
            />
            <div className="flex gap-3">
              <button
                onClick={() => setShowResolveModal(false)}
                className="flex-1 bg-slate-200 hover:bg-slate-300 text-slate-900 font-bold py-3 rounded-lg transition"
              >
                إلغاء
              </button>
              <button
                onClick={handleResolve}
                className="flex-1 bg-green-600 hover:bg-green-700 text-white font-bold py-3 rounded-lg transition"
              >
                تأكيد الإصلاح
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
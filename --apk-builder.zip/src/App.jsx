import { Routes, Route, Link } from "react-router-dom";
import Home from "./pages/Home.jsx";
import AdminDashboard from "./pages/AdminDashboard.jsx";
import AdminMap from "./pages/AdminMap.jsx";
import AdminUsers from "./pages/AdminUsers.jsx";
import AdminCoolers from "./pages/AdminCoolers.jsx";
import AdminContracts from "./pages/AdminContracts.jsx";
import AdminMaintenance from "./pages/AdminMaintenance.jsx";
import DelegateBarcodeScan from "./pages/DelegateBarcodeScan.jsx";
import DelegateNewContract from "./pages/DelegateNewContract.jsx";
import TechnicianTickets from "./pages/TechnicianTickets.jsx";
import TechnicianTicketId from "./pages/TechnicianTicketId.jsx";

export default function App() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      <header className="sticky top-0 z-40 backdrop-blur bg-slate-950/80 border-b border-white/10">
        <nav className="max-w-6xl mx-auto flex items-center gap-2 px-4 py-3 overflow-x-auto">
          <Link to="/" className="font-bold text-base mr-2 whitespace-nowrap">cooler-asset-manager</Link>
          <div className="flex gap-1 ml-auto">
          <Link to="/" className="px-3 py-2 rounded-lg text-sm text-slate-300 hover:bg-white/10 hover:text-white transition">Login</Link>
          <Link to="/admin/dashboard" className="px-3 py-2 rounded-lg text-sm text-slate-300 hover:bg-white/10 hover:text-white transition">Admin Dashboard</Link>
          <Link to="/admin/map" className="px-3 py-2 rounded-lg text-sm text-slate-300 hover:bg-white/10 hover:text-white transition">Coolers Map</Link>
          <Link to="/admin/users" className="px-3 py-2 rounded-lg text-sm text-slate-300 hover:bg-white/10 hover:text-white transition">User Management</Link>
          <Link to="/admin/coolers" className="px-3 py-2 rounded-lg text-sm text-slate-300 hover:bg-white/10 hover:text-white transition">Coolers Management</Link>
          <Link to="/admin/contracts" className="px-3 py-2 rounded-lg text-sm text-slate-300 hover:bg-white/10 hover:text-white transition">Contracts Management</Link>
          <Link to="/admin/maintenance" className="px-3 py-2 rounded-lg text-sm text-slate-300 hover:bg-white/10 hover:text-white transition">Maintenance Tickets</Link>
          <Link to="/delegate/barcode-scan" className="px-3 py-2 rounded-lg text-sm text-slate-300 hover:bg-white/10 hover:text-white transition">Barcode Scanner</Link>
          <Link to="/delegate/new-contract" className="px-3 py-2 rounded-lg text-sm text-slate-300 hover:bg-white/10 hover:text-white transition">New Contract Request</Link>
          <Link to="/technician/tickets" className="px-3 py-2 rounded-lg text-sm text-slate-300 hover:bg-white/10 hover:text-white transition">Maintenance Tickets List</Link>
          <Link to="/technician/ticket/:id" className="px-3 py-2 rounded-lg text-sm text-slate-300 hover:bg-white/10 hover:text-white transition">Ticket Details</Link>
          </div>
        </nav>
      </header>
      <main className="flex-1">
        <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/admin/dashboard" element={<AdminDashboard />} />
        <Route path="/admin/map" element={<AdminMap />} />
        <Route path="/admin/users" element={<AdminUsers />} />
        <Route path="/admin/coolers" element={<AdminCoolers />} />
        <Route path="/admin/contracts" element={<AdminContracts />} />
        <Route path="/admin/maintenance" element={<AdminMaintenance />} />
        <Route path="/delegate/barcode-scan" element={<DelegateBarcodeScan />} />
        <Route path="/delegate/new-contract" element={<DelegateNewContract />} />
        <Route path="/technician/tickets" element={<TechnicianTickets />} />
        <Route path="/technician/ticket/:id" element={<TechnicianTicketId />} />
        </Routes>
      </main>
      <footer className="border-t border-white/10 py-4 text-center text-xs text-slate-500">
        © 2026 cooler-asset-manager
      </footer>
    </div>
  );
}
